export enum ThemeColors {
  GREEN,
  PURPLE,
}
