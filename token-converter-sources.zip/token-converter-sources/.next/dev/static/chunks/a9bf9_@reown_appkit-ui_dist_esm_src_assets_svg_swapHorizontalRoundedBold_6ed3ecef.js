(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/a9bf9_@reown_appkit-ui_dist_esm_src_assets_svg_swapHorizontalRoundedBold_97664695.js"
],
    source: "dynamic"
});
