(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/app/components/atoms/Container.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Container
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
function Container({ className, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("max-w-[1406px] my-0 mx-auto", className),
        children: children
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Container.tsx",
        lineNumber: 9,
        columnNumber: 10
    }, this);
}
_c = Container;
var _c;
__turbopack_context__.k.register(_c, "Container");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Button.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ButtonColor",
    ()=>ButtonColor,
    "ButtonSize",
    ()=>ButtonSize,
    "ButtonVariant",
    ()=>ButtonVariant,
    "default",
    ()=>Button
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
;
var ButtonVariant = /*#__PURE__*/ function(ButtonVariant) {
    ButtonVariant["CONTAINED"] = "contained";
    ButtonVariant["OUTLINED"] = "outlined";
    return ButtonVariant;
}({});
var ButtonSize = /*#__PURE__*/ function(ButtonSize) {
    ButtonSize[ButtonSize["EXTRA_SMALL"] = 20] = "EXTRA_SMALL";
    ButtonSize[ButtonSize["SMALL"] = 32] = "SMALL";
    ButtonSize[ButtonSize["MEDIUM"] = 40] = "MEDIUM";
    ButtonSize[ButtonSize["LARGE"] = 48] = "LARGE";
    ButtonSize[ButtonSize["EXTRA_LARGE"] = 60] = "EXTRA_LARGE";
    return ButtonSize;
}({});
var ButtonColor = /*#__PURE__*/ function(ButtonColor) {
    ButtonColor[ButtonColor["GREEN"] = 0] = "GREEN";
    ButtonColor[ButtonColor["RED"] = 1] = "RED";
    ButtonColor[ButtonColor["LIGHT_GREEN"] = 2] = "LIGHT_GREEN";
    ButtonColor[ButtonColor["LIGHT_RED"] = 3] = "LIGHT_RED";
    ButtonColor[ButtonColor["LIGHT_YELLOW"] = 4] = "LIGHT_YELLOW";
    ButtonColor[ButtonColor["PURPLE"] = 5] = "PURPLE";
    ButtonColor[ButtonColor["LIGHT_PURPLE"] = 6] = "LIGHT_PURPLE";
    return ButtonColor;
}({});
const buttonVariantClassnameMap = {
    ["contained"]: {
        [1]: "bg-red text-primary-text hover:bg-red-hover",
        [0]: "bg-green text-black hover:bg-green-hover",
        [3]: "bg-red-bg text-secondary-text border-transparent border hover:border-red-light hover:bg-red-bg-hover hover:text-primary-text",
        [4]: "bg-yellow-bg text-secondary-text border-transparent border hover:border-yellow-light hover:bg-yellow-bg-hover hover:text-primary-text",
        [2]: "bg-green-bg text-secondary-text border-transparent border hover:border-green hover:bg-green-bg-hover hover:text-primary-text",
        [6]: "bg-purple-bg text-secondary-text border-transparent border hover:border-purple-hover hover:bg-purple-bg-hover hover:text-primary-text",
        [5]: "bg-purple text-secondary-bg hover:bg-purple-hover"
    },
    ["outlined"]: {
        [1]: "border border-primary text-secondary-text hover:bg-red-bg hover:border-primary-text hover:text-primary-text",
        [0]: "border border-green text-primary-text hover:bg-green-bg",
        [3]: "bg-red-light text-black hover:bg-red-hover",
        [4]: "bg-yellow-light text-black hover:bg-red-hover",
        [2]: "bg-green-bg text-primary-text border-transparent border hover:border-green",
        [5]: "bg-red-bg text-secondary-text border-transparent border hover:border-red-light hover:bg-red-bg-hover hover:text-primary-text",
        [6]: "bg-red-bg text-secondary-text border-transparent border hover:border-red-light hover:bg-red-bg-hover hover:text-primary-text"
    }
};
const buttonSizeClassnameMap = {
    [20]: "lg:text-12 lg:min-h-5 lg:rounded-20 lg:px-4",
    [32]: "lg:text-14 lg:font-medium lg:min-h-8 lg:rounded-20 lg:px-6",
    [40]: "lg:text-16 lg:font-medium lg:min-h-10 lg:rounded-2 lg:px-6",
    [48]: "lg:text-16 lg:font-medium lg:min-h-12 lg:rounded-3 lg:px-6",
    [60]: "lg:text-18 lg:font-medium lg:min-h-[60px] lg:rounded-3 lg:px-6"
};
const tabletButtonSizeClassnameMap = {
    [20]: "sm:text-12 sm:min-h-5 sm:rounded-20 sm:px-4",
    [32]: "sm:text-14 sm:font-medium sm:min-h-8 sm:rounded-20 sm:px-6",
    [40]: "sm:text-16 sm:font-medium sm:rounded-2 sm:min-h-10 sm:px-6",
    [48]: "sm:text-16 sm:font-medium sm:rounded-3 sm:min-h-12 sm:px-6",
    [60]: "sm:text-18 sm:font-medium sm:rounded-3 sm:min-h-[60px] sm:px-6"
};
const mobileButtonSizeClassnameMap = {
    [20]: "text-12 min-h-5 rounded-20 px-4",
    [32]: "text-14 font-medium rounded-2 min-h-8 px-6",
    [40]: "text-16 font-medium rounded-2 min-h-10 px-6",
    [48]: "text-16 font-medium rounded-3 min-h-12 px-6",
    [60]: "text-18 font-medium rounded-3 min-h-[60px] px-6"
};
const disabledClassnameMap = {
    ["contained"]: "disabled:bg-tertiary-bg disabled:text-secondary-text",
    ["outlined"]: "disabled:text-secondary-text disabled:border-secondary-border"
};
function Button({ variant = "contained", size = 48, mobileSize, tabletSize, startIcon, endIcon, fullWidth, colorScheme = 0, children, className, isLoading, ...props }) {
    const _mobileSize = mobileSize || size;
    const _tabletSize = tabletSize || size;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("flex items-center justify-center gap-2 duration-200 disabled:pointer-events-none", buttonVariantClassnameMap[variant][colorScheme], buttonSizeClassnameMap[size], tabletButtonSizeClassnameMap[_tabletSize], mobileButtonSizeClassnameMap[_mobileSize], fullWidth && "w-full", disabledClassnameMap[variant], isLoading && "opacity-50 pointer-events-none", className),
        ...props,
        children: [
            startIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                iconName: startIcon
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Button.tsx",
                lineNumber: 140,
                columnNumber: 21
            }, this),
            children,
            endIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                iconName: endIcon
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Button.tsx",
                lineNumber: 142,
                columnNumber: 19
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/Button.tsx",
        lineNumber: 126,
        columnNumber: 5
    }, this);
}
_c = Button;
var _c;
__turbopack_context__.k.register(_c, "Button");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Popover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Popover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/core/dist/floating-ui.core.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/react/dist/floating-ui.react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function Popover({ placement, isOpened, setIsOpened, children, trigger, customOffset, customStyles = {} }) {
    _s();
    const { refs, floatingStyles, context } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"])({
        open: isOpened,
        onOpenChange: setIsOpened,
        middleware: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])(customOffset || 24),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])({
                fallbackAxisSideDirection: "end",
                mainAxis: false
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$core$2f$dist$2f$floating$2d$ui$2e$core$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])()
        ],
        placement,
        whileElementsMounted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"]
    });
    const { isMounted, styles: transitionStyles } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTransitionStyles"])(context, {
        duration: {
            open: 200,
            close: 200
        }
    });
    const click = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useClick"])(context);
    const dismiss = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDismiss"])(context);
    const role = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useRole"])(context);
    const { getReferenceProps, getFloatingProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"])([
        click,
        dismiss,
        role
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].cloneElement(trigger, {
                ...getReferenceProps,
                ref: refs.setReference
            }),
            isMounted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FloatingPortal"], {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FloatingFocusManager"], {
                    context: context,
                    modal: false,
                    initialFocus: -1,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: refs.setFloating,
                        style: {
                            ...floatingStyles,
                            ...transitionStyles,
                            ...customStyles,
                            zIndex: 99
                        },
                        ...getFloatingProps(),
                        children: children
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/Popover.tsx",
                        lineNumber: 66,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Popover.tsx",
                    lineNumber: 65,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Popover.tsx",
                lineNumber: 64,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true);
}
_s(Popover, "TLwJhLdDVAwD0DjnMXs+2vN+dzY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTransitionStyles"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useClick"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDismiss"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useRole"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"]
    ];
});
_c = Popover;
var _c;
__turbopack_context__.k.register(_c, "Popover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/SelectButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SelectButton",
    ()=>SelectButton,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/theme-colors.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
;
;
;
;
const SelectButton = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(_c = ({ withArrow = true, isOpen = false, children, size = "regular", fullWidth = false, variant = "rectangle", className, colorScheme = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN, ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        ref: ref,
        ...props,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("group flex items-center gap-2 duration-200 text-base text-primary-text bg-primary-bg", props.disabled ? "opacity-20 pointer-events-none" : colorScheme === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN ? " hover:bg-green-bg hover:text-primary-text" : " hover:bg-purple-bg hover:text-primary-text", variant === "rectangle" && "rounded-2", variant === "rounded" && !props.disabled && (colorScheme === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN ? "rounded-[80px] border border-transparent hover:bg-green-bg hover:shadow shadow-green/60 hover:border-green" : " rounded-[80px] border border-transparent hover:bg-purple-bg hover:shadow shadow-purple/60 hover:border-purple"), variant === "rounded" && props.disabled && "rounded-[80px] border border-transparent opacity-20 pointer-events-none", isOpen && (colorScheme === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN ? "bg-green-bg border-green" : " bg-purple-bg border-purple"), size === "large" && "p-2 lg:px-5 lg:py-2.5 lg:text-24 min-h-12", size === "regular" && "py-2 px-3", size === "medium" && "py-2 lg:py-3 px-3", fullWidth && withArrow && "w-full justify-between", fullWidth && !withArrow && "w-full justify-center", className),
        children: [
            children,
            withArrow && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-secondary-text group-hover:text-primary-text", isOpen ? "-rotate-180" : "", "duration-200", "flex-shrink-0"),
                iconName: "small-expand-arrow"
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/SelectButton.tsx",
                lineNumber: 67,
                columnNumber: 11
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/SelectButton.tsx",
        lineNumber: 34,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = SelectButton;
SelectButton.displayName = "SelectButton";
const __TURBOPACK__default__export__ = SelectButton;
var _c, _c1;
__turbopack_context__.k.register(_c, "SelectButton$forwardRef");
__turbopack_context__.k.register(_c1, "SelectButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useCurrentChainId
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConnectWalletStore.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
function useCurrentChainId() {
    _s();
    const { chainId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const { chainToConnect } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectWalletStore"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useCurrentChainId.useMemo": ()=>{
            if (chainId && __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEX_SUPPORTED_CHAINS"].includes(chainId)) {
                return chainId;
            }
            return chainToConnect;
        }
    }["useCurrentChainId.useMemo"], [
        chainId,
        chainToConnect
    ]);
}
_s(useCurrentChainId, "Uqr+7rKMvA34c1DGvCvUrMCsWw4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectWalletStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/getExplorerLink.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ExplorerLinkType",
    ()=>ExplorerLinkType,
    "default",
    ()=>getExplorerLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
;
var ExplorerLinkType = /*#__PURE__*/ function(ExplorerLinkType) {
    ExplorerLinkType[ExplorerLinkType["ADDRESS"] = 0] = "ADDRESS";
    ExplorerLinkType[ExplorerLinkType["TRANSACTION"] = 1] = "TRANSACTION";
    ExplorerLinkType[ExplorerLinkType["BLOCK"] = 2] = "BLOCK";
    ExplorerLinkType[ExplorerLinkType["GAS_TRACKER"] = 3] = "GAS_TRACKER";
    ExplorerLinkType[ExplorerLinkType["TOKEN"] = 4] = "TOKEN";
    return ExplorerLinkType;
}({});
const explorerMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET]: "https://etherscan.io"
};
function getExplorerLink(type, value, chainId) {
    switch(type){
        case 0:
            return `${explorerMap[chainId]}/address/${value}`;
        case 1:
            return `${explorerMap[chainId]}/tx/${value}`;
        case 2:
            return `${explorerMap[chainId]}/block/${value}`;
        case 4:
            return `${explorerMap[chainId]}/token/${value}`;
        case 3:
            switch(chainId){
                case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET:
                    return `${explorerMap[chainId]}/gastracker`;
                default:
                    return `${explorerMap[chainId]}`;
            }
        default:
            return `${explorerMap[chainId]}`;
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/truncateMiddle.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>truncateMiddle
]);
function truncateMiddle(value, options = {
    charsFromStart: 6,
    charsFromEnd: 6
}) {
    if (value.length < options.charsFromStart + options.charsFromEnd) return value;
    return `${value.slice(0, options.charsFromStart)}...${options.charsFromEnd > 0 ? value.slice(-options.charsFromEnd) : ""}`;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/ExternalTextLink.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ExternalTextLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
;
function ExternalTextLink({ text, href, color = "green", className, arrowSize = 24, textClassname, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        ...props,
        target: "_blank",
        href: href,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("flex items-center duration-200", color === "green" ? "text-green hover:text-green-hover" : "text-white hover:text-green", className),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: textClassname,
                children: text
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/ExternalTextLink.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                iconName: "forward",
                className: "flex-shrink-0",
                size: arrowSize
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/ExternalTextLink.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/ExternalTextLink.tsx",
        lineNumber: 24,
        columnNumber: 5
    }, this);
}
_c = ExternalTextLink;
var _c;
__turbopack_context__.k.register(_c, "ExternalTextLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/dialogs/AccountDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>AccountDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$responsive$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-responsive/dist/esm/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useDisconnect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useDisconnect.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Drawer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/SelectButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$wallets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/wallets.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConnectWalletStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/getExplorerLink.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$truncateMiddle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/truncateMiddle.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$ExternalTextLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/ExternalTextLink.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function AccountDialogContent({ setIsOpenedAccount, activeTab, setActiveTab }) {
    _s();
    const { address } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const { disconnect } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useDisconnect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisconnect"])();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { connector } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "px-5 md:w-[460px] w-full max-h-[calc(100dvh_-_70px)]",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center my-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$wallets$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["wallets"].metamask.image,
                                alt: "",
                                width: 40,
                                height: 40
                            }, void 0, false, {
                                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                                lineNumber: 32,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {}, void 0, false, {
                                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                                lineNumber: 33,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex gap-1",
                                children: [
                                    address && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$ExternalTextLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        text: `${address.slice(0, 6)}...${address.slice(-4)}`,
                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExplorerLinkType"].ADDRESS, address, chainId)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                                        lineNumber: 37,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButtonVariant"].COPY,
                                        text: address || ""
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                                        lineNumber: 42,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                                lineNumber: 35,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                        lineNumber: 31,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: ()=>{
                            setIsOpenedAccount(false);
                            disconnect({
                                connector
                            });
                        },
                        className: "text-secondary-text flex items-center gap-2 hover:text-green duration-200",
                        children: [
                            "Disconnect",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                iconName: "logout"
                            }, void 0, false, {
                                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                                lineNumber: 53,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                        lineNumber: 45,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                lineNumber: 30,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
            lineNumber: 29,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_s(AccountDialogContent, "7/fbXSMahDtLdgC2f9vLPyywbx8=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useDisconnect$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDisconnect"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"]
    ];
});
_c = AccountDialogContent;
function AccountDialog() {
    _s1();
    const { isConnected, address, connector } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const { setIsOpened: setOpenedWallet } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectWalletDialogStateStore"])();
    const [activeTab, setActiveTab] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const _isMobile = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$responsive$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"])({
        query: "(max-width: 767px)"
    });
    const [isOpenedAccount, setIsOpenedAccount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const trigger = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "AccountDialog.useMemo[trigger]": ()=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "py-1 xl:py-2 text-14 xl:text-16 w-full md:w-auto flex items-center justify-center group",
                isOpen: isOpenedAccount,
                onClick: {
                    "AccountDialog.useMemo[trigger]": ()=>setIsOpenedAccount(!isOpenedAccount)
                }["AccountDialog.useMemo[trigger]"],
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "duration-200 flex gap-2 items-center text-secondary-text group-hover:text-primary-text",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            className: "duration-200 text-tertiary-text group-hover:text-primary-text",
                            iconName: "wallet"
                        }, void 0, false, {
                            fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                            lineNumber: 80,
                            columnNumber: 11
                        }, this),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$truncateMiddle$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(address || "", {
                            charsFromStart: 5,
                            charsFromEnd: 3
                        })
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                    lineNumber: 79,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                lineNumber: 74,
                columnNumber: 7
            }, this)
    }["AccountDialog.useMemo[trigger]"], [
        address,
        isOpenedAccount
    ]);
    const [isInitialized, setInitialized] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AccountDialog.useEffect": ()=>{
            setInitialized(true);
        }
    }["AccountDialog.useEffect"], []);
    if (!isInitialized) {
        return null;
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: isConnected && address ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: _isMobile ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    trigger,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        placement: "bottom",
                        isOpen: isOpenedAccount,
                        setIsOpen: setIsOpenedAccount,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AccountDialogContent, {
                            setIsOpenedAccount: setIsOpenedAccount,
                            activeTab: activeTab,
                            setActiveTab: setActiveTab
                        }, void 0, false, {
                            fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                            lineNumber: 109,
                            columnNumber: 17
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                        lineNumber: 108,
                        columnNumber: 15
                    }, this)
                ]
            }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpened: isOpenedAccount,
                    setIsOpened: setIsOpenedAccount,
                    placement: "bottom-end",
                    trigger: trigger,
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-primary-bg rounded-5 border border-secondary-border shadow-popover shadow-black/70",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AccountDialogContent, {
                            setIsOpenedAccount: setIsOpenedAccount,
                            activeTab: activeTab,
                            setActiveTab: setActiveTab
                        }, void 0, false, {
                            fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                            lineNumber: 125,
                            columnNumber: 19
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                        lineNumber: 124,
                        columnNumber: 17
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                    lineNumber: 118,
                    columnNumber: 15
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                lineNumber: 117,
                columnNumber: 13
            }, this)
        }, void 0, false) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                size: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].MEDIUM,
                tabletSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].SMALL,
                mobileSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].SMALL,
                className: "rounded-2 md:rounded-2 md:font-normal w-full md:w-auto",
                onClick: ()=>setOpenedWallet(true),
                children: "Connect wallet"
            }, void 0, false, {
                fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
                lineNumber: 137,
                columnNumber: 11
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/dialogs/AccountDialog.tsx",
            lineNumber: 136,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_s1(AccountDialog, "MQmpWeHyFDR17HAAS693ZpVoPZI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectWalletDialogStateStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$responsive$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMediaQuery"]
    ];
});
_c1 = AccountDialog;
var _c, _c1;
__turbopack_context__.k.register(_c, "AccountDialogContent");
__turbopack_context__.k.register(_c1, "AccountDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/layout/MobileMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MobileLink",
    ()=>MobileLink,
    "default",
    ()=>MobileMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$swipeable$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-swipeable/es/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Drawer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function MobileLink({ href, iconName, title, handleClose, isActive, disabled = false, className = "", linkClassName = "", handleClick, isMenu = false, isExternal = false, comingSoon = false }) {
    if (isExternal) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            target: "_blank",
            onClick: (e)=>{
                if (handleClick) {
                    handleClick(e);
                }
                handleClose();
            },
            href: href,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("flex items-center gap-2 py-3 px-4 duration-200", !isActive && "hover:bg-quaternary-bg text-secondary-text", isActive && !isMenu && "text-green pointer-events-none", isActive && isMenu && "bg-navigation-active-mobile text-green pointer-events-none", disabled && "pointer-events-none opacity-50", className),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    iconName: iconName
                }, void 0, false, {
                    fileName: "[project]/app/components/layout/MobileMenu.tsx",
                    lineNumber: 60,
                    columnNumber: 9
                }, this),
                title
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/layout/MobileMenu.tsx",
            lineNumber: 41,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex items-center gap-2", className),
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            onClick: (e)=>{
                if (handleClick) {
                    handleClick(e);
                }
                handleClose();
            },
            href: href,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("flex items-center gap-2 py-3 px-4 duration-200 flex-grow", !isActive && "hover:bg-quaternary-bg text-secondary-text", isActive && !isMenu && "text-green pointer-events-none", isActive && isMenu && "bg-navigation-active-mobile text-green pointer-events-none", disabled && "pointer-events-none opacity-50", linkClassName),
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    iconName: iconName
                }, void 0, false, {
                    fileName: "[project]/app/components/layout/MobileMenu.tsx",
                    lineNumber: 86,
                    columnNumber: 9
                }, this),
                title
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/layout/MobileMenu.tsx",
            lineNumber: 68,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/layout/MobileMenu.tsx",
        lineNumber: 67,
        columnNumber: 5
    }, this);
}
_c = MobileLink;
function NavigationExternalLink({ href, text }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        target: "_blank",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-green hover:text-green-hover duration-200 inline-block py-1", href === "#" && "opacity-50 pointer-events-none"),
        href: href,
        children: text
    }, void 0, false, {
        fileName: "[project]/app/components/layout/MobileMenu.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
_c1 = NavigationExternalLink;
function NavigationExternalLinksContainer({ title, links }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-primary-text",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-tertiary-text",
                children: title
            }, void 0, false, {
                fileName: "[project]/app/components/layout/MobileMenu.tsx",
                lineNumber: 117,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: links.map((link)=>{
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavigationExternalLink, {
                        href: link.href,
                        text: link.text
                    }, link.text, false, {
                        fileName: "[project]/app/components/layout/MobileMenu.tsx",
                        lineNumber: 120,
                        columnNumber: 18
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/app/components/layout/MobileMenu.tsx",
                lineNumber: 118,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/layout/MobileMenu.tsx",
        lineNumber: 116,
        columnNumber: 5
    }, this);
}
_c2 = NavigationExternalLinksContainer;
const mobileLinks = [
    {
        href: "/swap",
        iconName: "swap",
        title: "swap"
    },
    {
        href: "/margin-trading",
        iconName: "margin-trading",
        title: "margin_trading"
    },
    {
        href: "/buy-crypto",
        iconName: "fiat",
        title: "buy_crypto"
    },
    {
        href: "/pools",
        iconName: "pools",
        title: "pools"
    },
    {
        href: "/borrow",
        iconName: "borrow",
        title: "borrow_lend"
    },
    {
        href: "/portfolio",
        iconName: "portfolio",
        title: "portfolio"
    },
    {
        href: "/token-listing",
        iconName: "listing",
        title: "token_listing"
    }
];
function MobileMenu() {
    _s();
    const [mobileMenuOpened, setMobileMenuOpened] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    const handlers = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$swipeable$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSwipeable"])({
        onSwipedLeft: {
            "MobileMenu.useSwipeable[handlers]": (eventData)=>{
                setMobileMenuOpened(false);
            }
        }["MobileMenu.useSwipeable[handlers]"]
    });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "xl:hidden",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Drawer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                handlers: handlers,
                placement: "left",
                isOpen: mobileMenuOpened,
                setIsOpen: setMobileMenuOpened,
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col justify-between h-full min-w-[300px]",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "py-6 grid gap-1",
                        children: [
                            mobileLinks.map(({ href, iconName, title })=>{
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(MobileLink, {
                                    isMenu: true,
                                    href: href,
                                    iconName: iconName,
                                    title: title,
                                    handleClose: ()=>setMobileMenuOpened(false),
                                    isActive: pathname.includes(href)
                                }, href, false, {
                                    fileName: "[project]/app/components/layout/MobileMenu.tsx",
                                    lineNumber: 198,
                                    columnNumber: 19
                                }, this);
                            })
                        ]
                    }, void 0, false, {
                        fileName: "[project]/app/components/layout/MobileMenu.tsx",
                        lineNumber: 194,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/layout/MobileMenu.tsx",
                    lineNumber: 193,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/layout/MobileMenu.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                buttonSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButtonSize"].LARGE,
                iconName: "menu",
                onClick: ()=>setMobileMenuOpened(true)
            }, void 0, false, {
                fileName: "[project]/app/components/layout/MobileMenu.tsx",
                lineNumber: 213,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/layout/MobileMenu.tsx",
        lineNumber: 186,
        columnNumber: 5
    }, this);
}
_s(MobileMenu, "qToCTP6LK+f9JvV5Sw5RuzWmXfo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$swipeable$2f$es$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSwipeable"]
    ];
});
_c3 = MobileMenu;
var _c, _c1, _c2, _c3;
__turbopack_context__.k.register(_c, "MobileLink");
__turbopack_context__.k.register(_c1, "NavigationExternalLink");
__turbopack_context__.k.register(_c2, "NavigationExternalLinksContainer");
__turbopack_context__.k.register(_c3, "MobileMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/NavigationItem.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NavigationItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
;
;
;
function NavigationItem({ href, title, active, id }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: "relative",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("px-3 py-5 duration-200 inline-flex", active ? "bg-navigation-active text-green shadow-green/60 text-shadow" : "hover:bg-navigation-hover hover:text-green hover:shadow-green/60 hover:text-shadow text-secondary-text"),
            href: href,
            children: title
        }, void 0, false, {
            fileName: "[project]/app/components/atoms/NavigationItem.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/NavigationItem.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
_c = NavigationItem;
var _c;
__turbopack_context__.k.register(_c, "NavigationItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/layout/Navigation.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Navigation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$NavigationItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/NavigationItem.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function NavigationExternalLink({ href, text }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
        target: "_blank",
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-green hover:text-green-hover duration-200 inline-block py-1", href === "#" && "opacity-50 pointer-events-none"),
        href: href,
        children: text
    }, void 0, false, {
        fileName: "[project]/app/components/layout/Navigation.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = NavigationExternalLink;
function NavigationExternalLinksContainer({ title, links }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col text-16 text-primary-text gap-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-tertiary-text",
                children: title
            }, void 0, false, {
                fileName: "[project]/app/components/layout/Navigation.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col",
                children: links.map((link)=>{
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NavigationExternalLink, {
                        href: link.href,
                        text: link.text
                    }, link.text, false, {
                        fileName: "[project]/app/components/layout/Navigation.tsx",
                        lineNumber: 39,
                        columnNumber: 18
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/app/components/layout/Navigation.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/layout/Navigation.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_c1 = NavigationExternalLinksContainer;
const menuItems = [
    {
        label: "Convert tokens",
        href: "/"
    },
    {
        label: "How it works",
        href: "/how-it-works"
    },
    {
        label: "ERC-223",
        href: "/erc-223"
    },
    {
        label: "View address tokens",
        href: "/address-tokens"
    }
];
const socialLinks = [
    {
        title: "Announcements",
        href: "https://t.me/Dex_223",
        icon: "telegram"
    },
    {
        title: "Discussions",
        href: "https://t.me/Dex223_defi",
        icon: "telegram"
    },
    {
        title: "DEX223",
        href: "https://x.com/Dex_223",
        icon: "x"
    },
    {
        title: "Dexaran",
        href: "https://x.com/Dexaran",
        icon: "x"
    },
    {
        title: "Discord",
        href: "https://discord.gg/t5bdeGC5Jk",
        icon: "discord"
    }
];
function Navigation() {
    _s();
    const pathname = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("ul", {
        className: "hidden xl:flex items-center",
        children: menuItems.map((menuItem, index)=>{
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("li", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$NavigationItem$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: menuItem.label,
                    title: menuItem.label,
                    href: menuItem.href,
                    active: pathname.includes(menuItem.href)
                }, void 0, false, {
                    fileName: "[project]/app/components/layout/Navigation.tsx",
                    lineNumber: 107,
                    columnNumber: 13
                }, this)
            }, menuItem.label, false, {
                fileName: "[project]/app/components/layout/Navigation.tsx",
                lineNumber: 106,
                columnNumber: 11
            }, this);
        })
    }, void 0, false, {
        fileName: "[project]/app/components/layout/Navigation.tsx",
        lineNumber: 103,
        columnNumber: 5
    }, this);
}
_s(Navigation, "xbyQPtUVMO7MNj7WjJlpdWqRcTo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePathname"]
    ];
});
_c2 = Navigation;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "NavigationExternalLink");
__turbopack_context__.k.register(_c1, "NavigationExternalLinksContainer");
__turbopack_context__.k.register(_c2, "Navigation");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/ClientOnly.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ClientOnly
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function ClientOnly({ children }) {
    _s();
    const [hasMounted, setHasMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ClientOnly.useEffect": ()=>{
            setHasMounted(true);
        }
    }["ClientOnly.useEffect"], []);
    if (!hasMounted) return null;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: children
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/ClientOnly.tsx",
        lineNumber: 14,
        columnNumber: 10
    }, this);
}
_s(ClientOnly, "aiSd/DQPOnbbLLZZL0Xv/KtPBDg=");
_c = ClientOnly;
var _c;
__turbopack_context__.k.register(_c, "ClientOnly");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/SelectOption.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SelectOption
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
;
;
;
function SelectOption({ onClick, isActive, disabled = false, children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        onClick: onClick,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex gap-2 items-center py-3 px-5 bg-primary-bg hover:bg-quaternary-bg duration-200 w-full", isActive && "text-green pointer-events-none", disabled && "opacity-50 pointer-events-none"),
        children: [
            children,
            isActive && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "ml-auto",
                iconName: "check"
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/SelectOption.tsx",
                lineNumber: 23,
                columnNumber: 20
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/SelectOption.tsx",
        lineNumber: 13,
        columnNumber: 5
    }, this);
}
_c = SelectOption;
var _c;
__turbopack_context__.k.register(_c, "SelectOption");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/layout/NetworkPicker.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NetworkPicker
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useSwitchChain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useSwitchChain.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$ClientOnly$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/ClientOnly.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Popover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/SelectButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectOption$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/SelectOption.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConnectWalletStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function NetworkPicker() {
    _s();
    const [isOpened, setIsOpened] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { chainToConnect, setChainToConnect } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectWalletStore"])();
    const { chainId } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const currentNetwork = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NetworkPicker.useMemo[currentNetwork]": ()=>{
            if (chainId) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networks"].find({
                    "NetworkPicker.useMemo[currentNetwork]": (n)=>n.chainId === chainId
                }["NetworkPicker.useMemo[currentNetwork]"]);
            }
            return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networks"].find({
                "NetworkPicker.useMemo[currentNetwork]": (n)=>n.chainId === chainToConnect
            }["NetworkPicker.useMemo[currentNetwork]"]);
        }
    }["NetworkPicker.useMemo[currentNetwork]"], [
        chainId,
        chainToConnect
    ]);
    const { switchChainAsync } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useSwitchChain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSwitchChain"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$ClientOnly$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Popover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            isOpened: isOpened,
            setIsOpened: setIsOpened,
            placement: "bottom-start",
            trigger: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "pl-2 pr-1 py-1 xl:py-2 gap-0 md:gap-2 xl:px-3 text-secondary-text",
                isOpen: isOpened,
                onClick: ()=>setIsOpened(!isOpened),
                children: currentNetwork ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2 xl:min-w-[110px]",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: `${currentNetwork?.logo}`,
                            alt: "Ethereum",
                            width: 24,
                            height: 24
                        }, void 0, false, {
                            fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                            lineNumber: 38,
                            columnNumber: 17
                        }, void 0),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "hidden xl:inline",
                            children: currentNetwork?.name
                        }, void 0, false, {
                            fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                            lineNumber: 39,
                            columnNumber: 17
                        }, void 0)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                    lineNumber: 37,
                    columnNumber: 15
                }, void 0) : "Unknown network"
            }, void 0, false, {
                fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                lineNumber: 31,
                columnNumber: 11
            }, void 0),
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "py-1 text-16 bg-primary-bg rounded-2 min-w-[280px] shadow-popover shadow-black/70",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["networks"].map(({ chainId: _chainId, name, logo })=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectOption$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            onClick: async ()=>{
                                if (!chainId) {
                                    setChainToConnect(_chainId);
                                }
                                if (switchChainAsync) {
                                    try {
                                        await switchChainAsync({
                                            chainId: _chainId
                                        });
                                    } catch (e) {
                                        console.log(e);
                                    } finally{}
                                }
                                setIsOpened(false);
                            },
                            isActive: _chainId === currentNetwork?.chainId,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: logo,
                                    alt: name,
                                    width: 24,
                                    height: 24
                                }, void 0, false, {
                                    fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                                    lineNumber: 70,
                                    columnNumber: 19
                                }, this),
                                name
                            ]
                        }, _chainId, true, {
                            fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                            lineNumber: 51,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                    lineNumber: 48,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/layout/NetworkPicker.tsx",
                lineNumber: 47,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/layout/NetworkPicker.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/layout/NetworkPicker.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(NetworkPicker, "1kHrnjBWFZ5iU1P5wEPO4NIIV1s=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConnectWalletStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConnectWalletStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useSwitchChain$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useSwitchChain"]
    ];
});
_c = NetworkPicker;
var _c;
__turbopack_context__.k.register(_c, "NetworkPicker");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/layout/Header.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Header
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$dialogs$2f$AccountDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/dialogs/AccountDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$MobileMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/layout/MobileMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$Navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/layout/Navigation.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$NetworkPicker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/layout/NetworkPicker.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
function Header() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
            className: "md:mb-3 xl:before:hidden before:h-[1px] before:bg-gradient-to-r before:from-secondary-border/20 before:via-50% before:via-secondary-border before:to-secondary-border/20 before:w-full before:absolute relative before:bottom-0 before:left-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "pl-4 pr-1 md:px-5",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-5",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    className: "relative w-7 h-8 xl:w-[35px] xl:h-10",
                                    href: "/",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        src: "/images/logo-short.svg",
                                        alt: "",
                                        fill: true
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/layout/Header.tsx",
                                        lineNumber: 20,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/layout/Header.tsx",
                                    lineNumber: 19,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$Navigation$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/components/layout/Header.tsx",
                                    lineNumber: 22,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/layout/Header.tsx",
                            lineNumber: 18,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 md:gap-3",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$NetworkPicker$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/components/layout/Header.tsx",
                                    lineNumber: 25,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "fixed w-[calc(50%-20px)] bottom-4 right-4 md:static md:w-auto md:bottom-unset z-[88] md:z-[21]",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$dialogs$2f$AccountDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                        fileName: "[project]/app/components/layout/Header.tsx",
                                        lineNumber: 28,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/layout/Header.tsx",
                                    lineNumber: 27,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$MobileMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/app/components/layout/Header.tsx",
                                    lineNumber: 31,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/layout/Header.tsx",
                            lineNumber: 24,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/layout/Header.tsx",
                    lineNumber: 17,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/layout/Header.tsx",
                lineNumber: 16,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/layout/Header.tsx",
            lineNumber: 15,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/layout/Header.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_c = Header;
var _c;
__turbopack_context__.k.register(_c, "Header");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/config/standard.config.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Standard",
    ()=>Standard,
    "getTokenAddressForStandard",
    ()=>getTokenAddressForStandard
]);
var Standard = /*#__PURE__*/ function(Standard) {
    Standard["ERC20"] = "ERC-20";
    Standard["ERC223"] = "ERC-223";
    return Standard;
}({});
function getTokenAddressForStandard(token, standard) {
    return standard === "ERC-20" ? token.address0 : token.address1;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Badge.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "BadgeVariant",
    ()=>BadgeVariant,
    "default",
    ()=>Badge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
;
;
;
var BadgeVariant = /*#__PURE__*/ function(BadgeVariant) {
    BadgeVariant[BadgeVariant["COLORED"] = 0] = "COLORED";
    BadgeVariant[BadgeVariant["DEFAULT"] = 1] = "DEFAULT";
    BadgeVariant[BadgeVariant["PERCENTAGE"] = 2] = "PERCENTAGE";
    BadgeVariant[BadgeVariant["STANDARD"] = 3] = "STANDARD";
    return BadgeVariant;
}({});
const badgeImagesMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20]: {
        green: {
            small: "erc-20-green-small.svg",
            default: "erc-20-green.svg"
        },
        purple: {
            small: "erc-20-purple-small.svg",
            default: "erc-20-purple.svg"
        }
    },
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223]: {
        green: {
            small: "erc-223-green-small.svg",
            default: "erc-223-green.svg"
        },
        purple: {
            small: "erc-223-purple-small.svg",
            default: "erc-223-purple.svg"
        }
    }
};
const standardBadgeSizes = {
    small: {
        height: 16,
        width: {
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20]: 56,
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223]: 62
        }
    },
    default: {
        height: 20,
        width: {
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20]: 60,
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223]: 66
        }
    }
};
function Badge(props) {
    switch(props.variant){
        case 0:
        case undefined:
            {
                const { text, color = "green", size = "default", className } = props;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("rounded-5 px-2 font-medium box-border text-nowrap", color === "blue" && "bg-blue-bg shadow-[0_0_0_1px_theme(colors.blue)_inset] text-blue", color === "green" && "bg-erc-20-bg shadow-[0_0_0_1px_theme(colors.erc-20-border)_inset] text-erc-20-text", color === "green_outline" && "text-green shadow-[0_0_0_1px_theme(colors.green-bg)_inset]", color === "grey_outline" && "text-tertiary-text shadow-[0_0_0_1px_theme(colors.secondary-border)_inset]", color === "purple" && "bg-erc-223-bg shadow-[0_0_0_1px_theme(colors.erc-223-border)_inset] text-erc-223-text", color === "red" && "bg-red-bg shadow-[0_0_0_1px_theme(colors.red)_inset] text-red", color === "grey" && "bg-quaternary-bg text-secondary-text shadow-[0_0_0_1px_theme(colors.quaternary-bg)_inset]", size === "default" ? "text-12 py-0.5" : "text-10", className),
                    children: text
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Badge.tsx",
                    lineNumber: 95,
                    columnNumber: 9
                }, this);
            }
        case 1:
            {
                const { text: defaultText, size = "default", className } = props;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("bg-tertiary-bg text-secondary-text px-2 rounded-20 font-medium inline-block", size === "small" && "text-14", className),
                    children: defaultText
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Badge.tsx",
                    lineNumber: 122,
                    columnNumber: 9
                }, this);
            }
        case 2:
            {
                const { percentage, className } = props;
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("border border-secondary-border text-tertiary-text px-2 lg:px-3 rounded-5 h-5 lg:h-6 flex items-center justify-center text-12 lg:text-16", className),
                    children: typeof percentage === "number" ? `${percentage}% select` : percentage
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Badge.tsx",
                    lineNumber: 136,
                    columnNumber: 9
                }, this);
            }
        case 3:
            const { standard, color = "green", size = "default", className } = props;
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: className,
                src: `/images/badges/${badgeImagesMap[standard][color][size]}`,
                alt: "",
                width: standardBadgeSizes[size].width[standard],
                height: standardBadgeSizes[size].height
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Badge.tsx",
                lineNumber: 151,
                columnNumber: 9
            }, this);
    }
}
_c = Badge;
var _c;
__turbopack_context__.k.register(_c, "Badge");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "InputSize",
    ()=>InputSize,
    "InputWithArrows",
    ()=>InputWithArrows,
    "SearchInput",
    ()=>SearchInput,
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/theme-colors.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
var InputSize = /*#__PURE__*/ function(InputSize) {
    InputSize[InputSize["DEFAULT"] = 40] = "DEFAULT";
    InputSize[InputSize["LARGE"] = 48] = "LARGE";
    return InputSize;
}({});
const inputSizeMap = {
    [40]: "h-10 text-14 rounded-2",
    [48]: "h-12 text-16 rounded-2 md:rounded-3"
};
const Input = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["forwardRef"])(function Input({ isError = false, isWarning = false, className, inputSize = 48, colorScheme = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN, ...props }, ref) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("duration-200 focus:outline-0 pl-4 md:pl-5 placeholder:text-tertiary-text w-full bg-secondary-bg border text-primary-text", inputSizeMap[inputSize], !isError && !isWarning && (colorScheme === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN ? "border-transparent hover:shadow hover:shadow-green/60 focus:shadow focus:shadow-green focus:border-green" : "border-transparent hover:shadow hover:shadow-purple/60 focus:shadow focus:shadow-purple focus:border-purple"), isError && "border-red-light hover:shadow hover:shadow-red-light-shadow/60 focus:shadow focus:shadow-red-light-shadow/60", isWarning && "border-orange hover:shadow hover:shadow-orange/60 focus:shadow focus:shadow-orange/60", props.disabled && "opacity-50 pointer-events-none", props.readOnly && "pointer-events-none bg-primary-bg border-secondary-border", className),
        ...props
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Input.tsx",
        lineNumber: 38,
        columnNumber: 5
    }, this);
});
_c = Input;
Input.displayName = "Input";
const __TURBOPACK__default__export__ = Input;
function SearchInput(props) {
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleClear = ()=>{
        if (props.onChange) {
            props.onChange({
                target: {
                    value: ""
                }
            });
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("pr-12", props.className),
                style: props.style ? props.style : {
                    paddingRight: "2.5rem"
                },
                ref: ref,
                ...props
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Input.tsx",
                lineNumber: 76,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("absolute right-2 flex items-center justify-center h-full w-10 top-0", props.value === "" && "pointer-events-none"),
                children: props.value === "" || ref.current?.value === "" || !!props.noCloseIcon ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: "text-secondary-text",
                    iconName: "search"
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Input.tsx",
                    lineNumber: 89,
                    columnNumber: 11
                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    variant: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButtonVariant"].CLOSE,
                    className: "text-tertiary-text",
                    handleClose: ()=>{
                        handleClear();
                        ref.current?.focus();
                    }
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Input.tsx",
                    lineNumber: 91,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Input.tsx",
                lineNumber: 82,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/Input.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_s(SearchInput, "QMBuJFIdzLIeqBcFwhMf246mjOM=");
_c1 = SearchInput;
function InputWithArrows(props) {
    _s1();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const handleIncrement = ()=>{
    // if (props.onChange) {
    //   props.onChange({
    //     target: { value: +props.value + 1 },
    //   } as ChangeEvent<HTMLInputElement>);
    // }
    };
    const handleDecrement = ()=>{
    // if (props.onChange) {
    //   props.onChange({
    //     target: { value: props.value - 1 },
    //   } as ChangeEvent<HTMLInputElement>);
    // }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative w-full",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(Input, {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("pr-12", props.className),
                style: props.style ? props.style : {
                    paddingRight: "2.5rem"
                },
                ref: ref,
                ...props
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Input.tsx",
                lineNumber: 126,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("absolute right-2 flex items-center justify-center h-full w-10 top-0"),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            iconName: "add",
                            className: "text-tertiary-text",
                            onClick: handleIncrement
                        }, void 0, false, {
                            fileName: "[project]/app/components/atoms/Input.tsx",
                            lineNumber: 134,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            iconName: "add",
                            className: "text-tertiary-text",
                            onClick: handleDecrement
                        }, void 0, false, {
                            fileName: "[project]/app/components/atoms/Input.tsx",
                            lineNumber: 135,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Input.tsx",
                lineNumber: 132,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/Input.tsx",
        lineNumber: 125,
        columnNumber: 5
    }, this);
}
_s1(InputWithArrows, "QMBuJFIdzLIeqBcFwhMf246mjOM=");
_c2 = InputWithArrows;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "Input");
__turbopack_context__.k.register(_c1, "SearchInput");
__turbopack_context__.k.register(_c2, "InputWithArrows");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/config/addresses.config.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CONVERTER_ADDRESS",
    ()=>CONVERTER_ADDRESS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
;
const CONVERTER_ADDRESS = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET]: "0xe7E969012557f25bECddB717A3aa2f4789ba9f9a"
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/abis/erc20.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ERC20_ABI",
    ()=>ERC20_ABI
]);
const ERC20_ABI = [
    {
        constant: true,
        inputs: [],
        name: "name",
        outputs: [
            {
                name: "",
                type: "string"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: false,
        inputs: [
            {
                name: "_spender",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        name: "approve",
        outputs: [],
        payable: false,
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        constant: true,
        inputs: [],
        name: "totalSupply",
        outputs: [
            {
                name: "",
                type: "uint256"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: false,
        inputs: [
            {
                name: "_from",
                type: "address"
            },
            {
                name: "_to",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        name: "transferFrom",
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ],
        payable: false,
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        constant: true,
        inputs: [],
        name: "decimals",
        outputs: [
            {
                name: "",
                type: "uint8"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: true,
        inputs: [
            {
                name: "_owner",
                type: "address"
            }
        ],
        name: "balanceOf",
        outputs: [
            {
                name: "balance",
                type: "uint256"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: true,
        inputs: [],
        name: "symbol",
        outputs: [
            {
                name: "",
                type: "string"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        constant: false,
        inputs: [
            {
                name: "_to",
                type: "address"
            },
            {
                name: "_value",
                type: "uint256"
            }
        ],
        name: "transfer",
        outputs: [
            {
                name: "",
                type: "bool"
            }
        ],
        payable: false,
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        constant: true,
        inputs: [
            {
                name: "_owner",
                type: "address"
            },
            {
                name: "_spender",
                type: "address"
            }
        ],
        name: "allowance",
        outputs: [
            {
                name: "",
                type: "uint256"
            }
        ],
        payable: false,
        stateMutability: "view",
        type: "function"
    },
    {
        payable: true,
        stateMutability: "payable",
        type: "fallback"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                name: "owner",
                type: "address"
            },
            {
                indexed: true,
                name: "spender",
                type: "address"
            },
            {
                indexed: false,
                name: "value",
                type: "uint256"
            }
        ],
        name: "Approval",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                name: "from",
                type: "address"
            },
            {
                indexed: true,
                name: "to",
                type: "address"
            },
            {
                indexed: false,
                name: "value",
                type: "uint256"
            }
        ],
        name: "Transfer",
        type: "event"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/config/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "MAX_SAFE_INTEGER",
    ()=>MAX_SAFE_INTEGER,
    "USDT_ADDRESS_ERC_20",
    ()=>USDT_ADDRESS_ERC_20
]);
const MAX_SAFE_INTEGER = BigInt(Number.MAX_SAFE_INTEGER);
const USDT_ADDRESS_ERC_20 = "0xdAC17F958D2ee523a2206206994597C13D831ec7";
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/getTransactionWithRetries.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getTransactionWithRetries",
    ()=>getTransactionWithRetries
]);
async function getTransactionWithRetries({ hash, publicClient, maxRetries = 3, delay = 500 }) {
    for(let attempt = 0; attempt < maxRetries; attempt++){
        try {
            const transaction = await publicClient.getTransaction({
                hash
            });
            if (transaction) {
                return transaction;
            }
        } catch (err) {
            console.log(`Attempt ${attempt + 1}: Transaction not found yet.`);
        }
        await new Promise((resolve)=>setTimeout(resolve, delay * attempt));
    }
    //if we don't get transaction with tree attempts we assume that this is metamask smart transactions and wait for
    // the receipt before retrieveing transaction by hash.
    try {
        await publicClient.waitForTransactionReceipt({
            hash
        });
        const transaction = await publicClient.getTransaction({
            hash
        });
        if (transaction) {
            return transaction;
        }
    } catch (err) {
        throw new Error("Transaction not found after retries.");
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useAllowance.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useStoreAllowance",
    ()=>useStoreAllowance
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/usePublicClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useReadContract.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useWalletClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useWalletClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/abis/erc20.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$addToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/addToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getTransactionWithRetries$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/getTransactionWithRetries.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
const allowanceGasLimitMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET]: {
        base: BigInt(50000),
        additional: BigInt(12000)
    }
};
const defaultApproveValue = BigInt(46000);
function useStoreAllowance({ token, contractAddress, amountToCheck }) {
    _s();
    const { address } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const publicClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"])();
    const { data: walletClient } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useWalletClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletClient"])();
    const { refetch, data: currentAllowanceData } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC20_ABI"],
        address: token?.address0,
        functionName: "allowance",
        args: [
            //set ! to avoid ts errors, make sure it is not undefined with "enabled" option
            address,
            contractAddress
        ],
        scopeKey: `${token?.address0}-${contractAddress}-${address}-${chainId}`,
        query: {
            //make sure hook don't run when there is no addresses
            enabled: Boolean(token?.address0) && Boolean(address) && Boolean(contractAddress)
        }
    });
    const gasLimit = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useStoreAllowance.useMemo[gasLimit]": ()=>{
            if (allowanceGasLimitMap[chainId]) {
                return allowanceGasLimitMap[chainId].additional + allowanceGasLimitMap[chainId].base;
            }
            return defaultApproveValue;
        }
    }["useStoreAllowance.useMemo[gasLimit]"], [
        chainId
    ]);
    const waitAndReFetch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStoreAllowance.useCallback[waitAndReFetch]": async (hash)=>{
            if (publicClient) {
                await publicClient.waitForTransactionReceipt({
                    hash
                });
                await refetch();
            }
        }
    }["useStoreAllowance.useCallback[waitAndReFetch]"], [
        publicClient,
        refetch
    ]);
    const isAllowed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useStoreAllowance.useMemo[isAllowed]": ()=>{
            return Boolean(currentAllowanceData && amountToCheck && currentAllowanceData >= amountToCheck);
        }
    }["useStoreAllowance.useMemo[isAllowed]"], [
        amountToCheck,
        currentAllowanceData
    ]);
    const writeTokenApprove = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useStoreAllowance.useCallback[writeTokenApprove]": async ({ customAmount, customGasSettings })=>{
            const amountToApprove = customAmount || amountToCheck;
            if (!amountToApprove || !contractAddress || !token || !walletClient || !address || !chainId || !publicClient) {
                console.error("Error: writeTokenApprove ~ something undefined");
                return;
            }
            const params = {
                address: token.address0,
                account: address,
                abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC20_ABI"],
                functionName: "approve",
                args: [
                    contractAddress,
                    amountToApprove
                ]
            };
            // USDT can't rewrite existing allowance, so we have to manually revoke allowance
            // to 0 before we can attach an allowance. This flag check if token can rewrite allowance,
            // that in this case with USDT results to true
            const isNotAvailableToRewriteAllowance = token.address0.toLowerCase() === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["USDT_ADDRESS_ERC_20"].toLowerCase();
            if (!isAllowed && currentAllowanceData !== BigInt(0) && isNotAvailableToRewriteAllowance) {
                const revokeParams = {
                    ...params,
                    args: [
                        contractAddress,
                        BigInt(0)
                    ]
                };
                //we are calling the same approve with 0 as amount to approve
                const hash = await walletClient.writeContract({
                    ...revokeParams,
                    ...customGasSettings || {},
                    gas: gasLimit,
                    account: undefined
                });
            // we wait until first function is ready so we are sure that second one will write
            // await publicClient.waitForTransactionReceipt({ hash });
            }
            try {
                let hash;
                try {
                    if (isNotAvailableToRewriteAllowance) {
                        hash = await walletClient.writeContract({
                            ...params,
                            ...customGasSettings || {},
                            args: [
                                contractAddress,
                                __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_SAFE_INTEGER"]
                            ],
                            gas: gasLimit,
                            account: undefined
                        });
                    } else {
                        const { request } = await publicClient.simulateContract({
                            ...params,
                            ...customGasSettings || {},
                            gas: gasLimit
                        });
                        hash = await walletClient.writeContract({
                            ...request,
                            account: undefined
                        });
                    }
                } catch (e) {
                    console.log(e);
                }
                if (hash) {
                    const transaction = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getTransactionWithRetries$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTransactionWithRetries"])({
                        hash,
                        publicClient
                    });
                    if (transaction) {
                        const transaction = await publicClient.getTransaction({
                            hash,
                            blockTag: "pending"
                        });
                        const nonce = transaction.nonce;
                        // no await needed, function should return hash without waiting
                        waitAndReFetch(hash);
                        return {
                            success: true,
                            hash
                        };
                    }
                }
                return {
                    success: false
                };
            } catch (e) {
                console.log(e);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$addToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(e.toString(), "error");
                return {
                    success: false
                };
            }
        }
    }["useStoreAllowance.useCallback[writeTokenApprove]"], [
        amountToCheck,
        contractAddress,
        token,
        walletClient,
        address,
        chainId,
        publicClient,
        isAllowed,
        currentAllowanceData,
        gasLimit,
        waitAndReFetch
    ]);
    return {
        isAllowed,
        writeTokenApprove,
        currentAllowance: currentAllowanceData,
        estimatedGas: allowanceGasLimitMap[chainId]?.base || defaultApproveValue,
        updateAllowance: refetch
    };
}
_s(useStoreAllowance, "GBsNH4DE+6oamoz7eMinSSjWGN0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useWalletClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/abis/erc223.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ERC223_ABI",
    ()=>ERC223_ABI
]);
const ERC223_ABI = [
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "owner",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "spender",
                type: "address"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "amount",
                type: "uint256"
            }
        ],
        name: "Approval",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "from",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "amount",
                type: "uint256"
            }
        ],
        name: "Transfer",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "from",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "to",
                type: "address"
            },
            {
                indexed: false,
                internalType: "uint256",
                name: "value",
                type: "uint256"
            },
            {
                indexed: false,
                internalType: "bytes",
                name: "data",
                type: "bytes"
            }
        ],
        name: "Transfer",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: false,
                internalType: "bytes",
                name: "data",
                type: "bytes"
            }
        ],
        name: "TransferData",
        type: "event"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "owner",
                type: "address"
            },
            {
                internalType: "address",
                name: "spender",
                type: "address"
            }
        ],
        name: "allowance",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_spender",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_value",
                type: "uint256"
            }
        ],
        name: "approve",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_owner",
                type: "address"
            }
        ],
        name: "balanceOf",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "uint256",
                name: "_quantity",
                type: "uint256"
            }
        ],
        name: "burn",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [],
        name: "creator",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "decimals",
        outputs: [
            {
                internalType: "uint8",
                name: "",
                type: "uint8"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "extractor",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_recipient",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_quantity",
                type: "uint256"
            }
        ],
        name: "mint",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [],
        name: "name",
        outputs: [
            {
                internalType: "string",
                name: "",
                type: "string"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "origin",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_amount",
                type: "uint256"
            }
        ],
        name: "rescueERC20",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_wrapper_for",
                type: "address"
            }
        ],
        name: "set",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [],
        name: "standard",
        outputs: [
            {
                internalType: "uint32",
                name: "",
                type: "uint32"
            }
        ],
        stateMutability: "pure",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "bytes4",
                name: "interfaceId",
                type: "bytes4"
            }
        ],
        name: "supportsInterface",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "symbol",
        outputs: [
            {
                internalType: "string",
                name: "",
                type: "string"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [],
        name: "totalSupply",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_value",
                type: "uint256"
            }
        ],
        name: "transfer",
        outputs: [
            {
                internalType: "bool",
                name: "success",
                type: "bool"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_value",
                type: "uint256"
            },
            {
                internalType: "bytes",
                name: "_data",
                type: "bytes"
            }
        ],
        name: "transfer",
        outputs: [
            {
                internalType: "bool",
                name: "success",
                type: "bool"
            }
        ],
        stateMutability: "payable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_from",
                type: "address"
            },
            {
                internalType: "address",
                name: "_to",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_value",
                type: "uint256"
            }
        ],
        name: "transferFrom",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/abis/tokenConverter.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "TOKEN_CONVERTER_ABI",
    ()=>TOKEN_CONVERTER_ABI
]);
const TOKEN_CONVERTER_ABI = [
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_amount",
                type: "uint256"
            }
        ],
        name: "convertERC20",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "createERC20Wrapper",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "createERC223Wrapper",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "_token",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "_ERC20Wrapper",
                type: "address"
            }
        ],
        name: "ERC20WrapperCreated",
        type: "event"
    },
    {
        anonymous: false,
        inputs: [
            {
                indexed: true,
                internalType: "address",
                name: "_token",
                type: "address"
            },
            {
                indexed: true,
                internalType: "address",
                name: "_ERC223Wrapper",
                type: "address"
            }
        ],
        name: "ERC223WrapperCreated",
        type: "event"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "extractStuckERC20",
        outputs: [],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_from",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_value",
                type: "uint256"
            },
            {
                internalType: "bytes",
                name: "",
                type: "bytes"
            }
        ],
        name: "tokenReceived",
        outputs: [
            {
                internalType: "bytes4",
                name: "",
                type: "bytes4"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_ERC20token",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_amount",
                type: "uint256"
            }
        ],
        name: "unwrapERC20toERC223",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_ERC20token",
                type: "address"
            },
            {
                internalType: "uint256",
                name: "_amount",
                type: "uint256"
            }
        ],
        name: "wrapERC20toERC223",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "nonpayable",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        name: "erc20Origins",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        name: "erc20Supply",
        outputs: [
            {
                internalType: "uint256",
                name: "",
                type: "uint256"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        name: "erc20Wrappers",
        outputs: [
            {
                internalType: "contract ERC20WrapperToken",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        name: "erc223Origins",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        name: "erc223Wrappers",
        outputs: [
            {
                internalType: "contract ERC223WrapperToken",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "getERC20OriginFor",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "getERC20WrapperFor",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "getERC223OriginFor",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "getERC223WrapperFor",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            }
        ],
        name: "isWrapper",
        outputs: [
            {
                internalType: "bool",
                name: "",
                type: "bool"
            }
        ],
        stateMutability: "view",
        type: "function"
    },
    {
        inputs: [
            {
                internalType: "address",
                name: "_token",
                type: "address"
            },
            {
                internalType: "bool",
                name: "_isERC20",
                type: "bool"
            }
        ],
        name: "predictWrapperAddress",
        outputs: [
            {
                internalType: "address",
                name: "",
                type: "address"
            }
        ],
        stateMutability: "view",
        type: "function"
    }
];
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useDeepEffect.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash.isequal/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const useDeepEffect = (callback, deps)=>{
    _s();
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])([]);
    if (!(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$isequal$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(deps, ref.current)) {
        ref.current = deps;
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(callback, [
        ref.current
    ]);
};
_s(useDeepEffect, "8uVE59eA/r6b92xF80p7sH8rXLk=");
const __TURBOPACK__default__export__ = useDeepEffect;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/services/blockTicker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// lib/blockTicker.ts
__turbopack_context__.s([
    "ensureBlockTicker",
    ()=>ensureBlockTicker,
    "stopBlockTicker",
    ()=>stopBlockTicker,
    "useBlockTickerStore",
    ()=>useBlockTickerStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$wagmi$2f$core$2f$dist$2f$esm$2f$actions$2f$watchBlockNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@wagmi/core/dist/esm/actions/watchBlockNumber.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$traditional$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/traditional.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$wagmi$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/wagmi.config.ts [app-client] (ecmascript)");
;
;
;
;
const useBlockTickerStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$traditional$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createWithEqualityFn"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subscribeWithSelector"])(()=>({
        lastByChain: {},
        startedByChain: {},
        unwatchByChain: {}
    })));
function throttle(fn, ms) {
    let last = 0, t, args;
    return function(...a) {
        const now = Date.now();
        args = a;
        if (now - last >= ms) {
            last = now;
            fn.apply(this, args);
        } else {
            clearTimeout(t);
            t = setTimeout(()=>{
                last = Date.now();
                fn.apply(this, args);
            }, ms - (now - last));
        }
    };
}
function ensureBlockTicker(opts) {
    const chainId = opts?.chainId;
    if (!chainId) return;
    const { startedByChain, unwatchByChain } = useBlockTickerStore.getState();
    if (startedByChain[chainId]) return;
    useBlockTickerStore.setState((s)=>({
            startedByChain: {
                ...s.startedByChain,
                [chainId]: true
            }
        }));
    const emit = throttle((bn)=>{
        if (typeof bn === "bigint") {
            useBlockTickerStore.setState((s)=>({
                    lastByChain: {
                        ...s.lastByChain,
                        [chainId]: bn
                    }
                }));
        }
    }, opts?.throttleMs ?? 1200);
    const unwatch = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$wagmi$2f$core$2f$dist$2f$esm$2f$actions$2f$watchBlockNumber$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["watchBlockNumber"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$wagmi$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["config"], {
        chainId,
        poll: true,
        emitOnBegin: true,
        pollingInterval: opts?.pollingIntervalMs ?? 4000,
        onBlockNumber: emit,
        onError: (e)=>console.error("[blockTicker]", e)
    });
    useBlockTickerStore.setState((s)=>({
            unwatchByChain: {
                ...s.unwatchByChain,
                [chainId]: unwatch
            }
        }));
}
function stopBlockTicker(chainId) {
    const { unwatchByChain } = useBlockTickerStore.getState();
    unwatchByChain[chainId]?.();
    useBlockTickerStore.setState((s)=>({
            startedByChain: {
                ...s.startedByChain,
                [chainId]: false
            },
            unwatchByChain: {
                ...s.unwatchByChain,
                [chainId]: undefined
            },
            lastByChain: {
                ...s.lastByChain,
                [chainId]: undefined
            }
        }));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/services/feesTicker.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ensureFeeTicker",
    ()=>ensureFeeTicker,
    "useFeeTickerStore",
    ()=>useFeeTickerStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/middleware.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$blockTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/services/blockTicker.ts [app-client] (ecmascript)");
;
;
;
const useFeeTickerStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])()((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$middleware$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["subscribeWithSelector"])(()=>({
        byChain: {},
        inflight: {}
    })));
/** de-dup: не більше одного фетча одночасно на chainId */ async function fetchFeesOnce(chainId, blockNumber, client) {
    if (!client) return; // якщо немає клієнта – нічого не робимо
    const s = useFeeTickerStore.getState();
    if (s.inflight[chainId]) return s.inflight[chainId];
    const p = (async ()=>{
        useFeeTickerStore.setState((st)=>({
                byChain: {
                    ...st.byChain,
                    [chainId]: {
                        ...st.byChain[chainId] || {},
                        loading: true,
                        error: null
                    }
                }
            }));
        try {
            const [eip1559, gasPrice, block] = await Promise.all([
                client.estimateFeesPerGas().catch(()=>undefined),
                client.getGasPrice().catch(()=>undefined),
                client.getBlock({
                    blockTag: "latest"
                }).catch(()=>undefined)
            ]);
            useFeeTickerStore.setState((st)=>({
                    byChain: {
                        ...st.byChain,
                        [chainId]: {
                            gasPrice,
                            baseFee: eip1559?.maxFeePerGas,
                            priorityFee: eip1559?.maxPriorityFeePerGas,
                            updatedAtBlock: blockNumber,
                            timestamp: block?.timestamp,
                            loading: false,
                            error: null
                        }
                    }
                }));
        } catch (e) {
            useFeeTickerStore.setState((st)=>({
                    byChain: {
                        ...st.byChain,
                        [chainId]: {
                            ...st.byChain[chainId] || {},
                            loading: false,
                            error: e?.message ?? "fee fetch failed"
                        }
                    }
                }));
        } finally{
            useFeeTickerStore.setState((st)=>({
                    inflight: {
                        ...st.inflight,
                        [chainId]: undefined
                    }
                }));
        }
    })();
    useFeeTickerStore.setState((st)=>({
            inflight: {
                ...st.inflight,
                [chainId]: p
            }
        }));
    return p;
}
function ensureFeeTicker(chainId, client) {
    if (!client) return;
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$blockTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureBlockTicker"])({
        chainId
    });
    let prev;
    return __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$blockTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useBlockTickerStore"].subscribe((st)=>st.lastByChain[chainId], (bn)=>{
        if (!bn || bn === prev) return;
        prev = bn;
        void fetchFeesOnce(chainId, bn, client);
    }, {
        fireImmediately: true
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useGlobalFees.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useGlobalFees",
    ()=>useGlobalFees
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/usePublicClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$feesTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/services/feesTicker.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
function useGlobalFees() {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const publicClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"])({
        chainId
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useGlobalFees.useEffect": ()=>{
            if (!chainId || !publicClient) return;
            const unsub = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$feesTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ensureFeeTicker"])(chainId, publicClient); // ідемпотентно
            return ({
                "useGlobalFees.useEffect": ()=>unsub?.()
            })["useGlobalFees.useEffect"]; // опційно
        }
    }["useGlobalFees.useEffect"], [
        chainId,
        publicClient
    ]);
    const snap = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$feesTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFeeTickerStore"])({
        "useGlobalFees.useFeeTickerStore[snap]": (s)=>chainId ? s.byChain[chainId] : undefined
    }["useGlobalFees.useFeeTickerStore[snap]"]);
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useGlobalFees.useMemo": ()=>({
                gasPrice: snap?.gasPrice,
                baseFee: snap?.baseFee,
                priorityFee: snap?.priorityFee,
                updatedAtBlock: snap?.updatedAtBlock,
                loading: snap?.loading ?? true,
                error: snap?.error ?? null,
                timestamp: snap?.timestamp
            })
    }["useGlobalFees.useMemo"], [
        snap
    ]);
}
_s(useGlobalFees, "rZJf3umjrAH4w3aBdeNNuOX2h7A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$services$2f$feesTicker$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFeeTickerStore"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/useConvertAmountStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useConvertAmountStore",
    ()=>useConvertAmountStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const useConvertAmountStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        typedValue: "",
        setTypedValue: ({ typedValue })=>{
            set({
                typedValue
            });
        },
        reset: ()=>set({
                typedValue: ""
            })
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/factories/createGasLimitStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createGasLimitStore",
    ()=>createGasLimitStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const initialGasLimitSettings = {
    customGasLimit: undefined,
    estimatedGas: BigInt(0)
};
const createGasLimitStore = (initialData = initialGasLimitSettings)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
            customGasLimit: initialData.customGasLimit,
            estimatedGas: initialData.estimatedGas,
            setCustomGasLimit: (gasLimit)=>set({
                    customGasLimit: gasLimit
                }),
            setEstimatedGas: (estimatedGas)=>set({
                    estimatedGas
                })
        }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/config/eip1559.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "eip1559SupportMap",
    ()=>eip1559SupportMap,
    "isEip1559Supported",
    ()=>isEip1559Supported
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
;
const eip1559SupportMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET]: true
};
function isEip1559Supported(chainId) {
    return eip1559SupportMap[chainId];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GasFeeModel",
    ()=>GasFeeModel,
    "GasOption",
    ()=>GasOption,
    "createGasPriceStore",
    ()=>createGasPriceStore,
    "initialGasPriceSettingsEIP1559",
    ()=>initialGasPriceSettingsEIP1559,
    "initialGasPriceSettingsLegacy",
    ()=>initialGasPriceSettingsLegacy
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/eip1559.ts [app-client] (ecmascript)");
;
;
var GasFeeModel = /*#__PURE__*/ function(GasFeeModel) {
    GasFeeModel[GasFeeModel["EIP1559"] = 0] = "EIP1559";
    GasFeeModel[GasFeeModel["LEGACY"] = 1] = "LEGACY";
    return GasFeeModel;
}({});
var GasOption = /*#__PURE__*/ function(GasOption) {
    GasOption[GasOption["CHEAP"] = 0] = "CHEAP";
    GasOption[GasOption["FAST"] = 1] = "FAST";
    GasOption[GasOption["CUSTOM"] = 2] = "CUSTOM";
    return GasOption;
}({});
const initialGasPriceSettingsEIP1559 = {
    gasPriceOption: 0,
    gasPriceSettings: {
        model: 0,
        maxFeePerGas: undefined,
        maxPriorityFeePerGas: undefined
    }
};
const initialGasPriceSettingsLegacy = {
    gasPriceOption: 0,
    gasPriceSettings: {
        model: 1,
        gasPrice: undefined
    }
};
const createGasPriceStore = (initialData = initialGasPriceSettingsEIP1559)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
            gasPriceOption: initialData.gasPriceOption,
            gasPriceSettings: initialData.gasPriceSettings,
            setGasPriceOption: (gasPriceOption)=>set({
                    gasPriceOption
                }),
            setGasPriceSettings: (gasPriceSettings)=>set({
                    gasPriceSettings
                }),
            updateDefaultState: (chainId)=>set(()=>{
                    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEip1559Supported"])(chainId)) {
                        return initialGasPriceSettingsEIP1559;
                    } else {
                        return initialGasPriceSettingsLegacy;
                    }
                })
        }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/factories/createGasSettingsStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createGasModeStore",
    ()=>createGasModeStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
const initialGasMode = {
    isAdvanced: false
};
const createGasModeStore = (initialData = initialGasMode)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
            isAdvanced: initialData.isAdvanced,
            setIsAdvanced: (isAdvanced)=>set({
                    isAdvanced
                })
        }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/useConvertGasSettingsStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useConvertGasLimitStore",
    ()=>useConvertGasLimitStore,
    "useConvertGasModeStore",
    ()=>useConvertGasModeStore,
    "useConvertGasPriceStore",
    ()=>useConvertGasPriceStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasLimitStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasLimitStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasSettingsStore.ts [app-client] (ecmascript)");
;
;
;
const useConvertGasPriceStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGasPriceStore"])();
const useConvertGasLimitStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasLimitStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGasLimitStore"])();
const useConvertGasModeStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createGasModeStore"])();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/factories/createOperationStatusStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createOperationStatusStore",
    ()=>createOperationStatusStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
function createOperationStatusStore({ initialStatus, errorType, operations }) {
    const storeCreator = (set, get)=>{
        const hashFields = Object.fromEntries(operations.map((key)=>[
                `${key}Hash`,
                undefined
            ]));
        const hashSetters = Object.fromEntries(operations.map((key)=>{
            const fnName = `set${key.charAt(0).toUpperCase()}${key.slice(1)}Hash`;
            const fieldName = `${key}Hash`;
            const fn = (hash)=>set({
                    [fieldName]: hash
                });
            return [
                fnName,
                fn
            ];
        }));
        const staticStoreFields = {
            status: initialStatus,
            errorType,
            setStatus: (status)=>{
                if (status === initialStatus) {
                    set({
                        ...hashFields,
                        status
                    });
                } else {
                    set({
                        status
                    });
                }
            },
            setErrorType: (errorType)=>set({
                    errorType
                })
        };
        return {
            ...staticStoreFields,
            ...hashFields,
            ...hashSetters
        };
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])(storeCreator);
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/useConvertStatusStore.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ConvertError",
    ()=>ConvertError,
    "ConvertStatus",
    ()=>ConvertStatus,
    "useConvertStatusStore",
    ()=>useConvertStatusStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createOperationStatusStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createOperationStatusStore.ts [app-client] (ecmascript)");
;
var ConvertStatus = /*#__PURE__*/ function(ConvertStatus) {
    ConvertStatus[ConvertStatus["INITIAL"] = 0] = "INITIAL";
    ConvertStatus[ConvertStatus["PENDING_APPROVE"] = 1] = "PENDING_APPROVE";
    ConvertStatus[ConvertStatus["LOADING_APPROVE"] = 2] = "LOADING_APPROVE";
    ConvertStatus[ConvertStatus["ERROR_APPROVE"] = 3] = "ERROR_APPROVE";
    ConvertStatus[ConvertStatus["PENDING_CONVERT"] = 4] = "PENDING_CONVERT";
    ConvertStatus[ConvertStatus["LOADING_CONVERT"] = 5] = "LOADING_CONVERT";
    ConvertStatus[ConvertStatus["ERROR_CONVERT"] = 6] = "ERROR_CONVERT";
    ConvertStatus[ConvertStatus["SUCCESS"] = 7] = "SUCCESS";
    return ConvertStatus;
}({});
var ConvertError = /*#__PURE__*/ function(ConvertError) {
    ConvertError[ConvertError["OUT_OF_GAS"] = 0] = "OUT_OF_GAS";
    ConvertError[ConvertError["UNKNOWN"] = 1] = "UNKNOWN";
    return ConvertError;
}({});
const useConvertStatusStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createOperationStatusStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createOperationStatusStore"])({
    initialStatus: 0,
    operations: [
        "approve",
        "convert"
    ],
    errorType: 1
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/useConvertTokenStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useConvertTokensStore",
    ()=>useConvertTokensStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
;
;
const useConvertTokensStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set, get)=>({
        token: {
            chainId: 1,
            symbol: "USDT",
            address0: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
            address1: "0xB8f0a8FCCB9F1d3d287A35643E93b8A7ee5E6980",
            name: "Tether USD",
            decimals: 6,
            logoURI: "https://etherscan.io/token/images/tethernew_32.svg"
        },
        tokenStandard: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20,
        setToken: (token)=>set({
                token
            }),
        setTokenStandard: (tokenStandard)=>set({
                tokenStandard
            }),
        switchStandard: ()=>set({
                tokenStandard: get().tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223 : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20
            }),
        reset: ()=>set({
                token: undefined,
                tokenStandard: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20
            })
    }));
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/config/baseFeeMultipliers.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SCALING_FACTOR",
    ()=>SCALING_FACTOR,
    "baseFeeMultipliers",
    ()=>baseFeeMultipliers
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)");
;
;
const baseFeeMultipliers = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET]: {
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP]: BigInt(120),
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].FAST]: BigInt(200)
    }
};
const SCALING_FACTOR = BigInt(100);
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/gasSettings.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getFormattedGasPrice",
    ()=>getFormattedGasPrice,
    "getGasSettings",
    ()=>getGasSettings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/baseFeeMultipliers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)");
;
;
const getGasSettings = ({ baseFee, chainId, gasPrice, priorityFee, gasPriceOption, gasPriceSettings })=>{
    if (gasPriceOption !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM) {
        const multiplier = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][gasPriceOption];
        switch(gasPriceSettings.model){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559:
                if (priorityFee && baseFee) {
                    return {
                        maxPriorityFeePerGas: priorityFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"],
                        maxFeePerGas: baseFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]
                    };
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY:
                if (gasPrice) {
                    return {
                        gasPrice: gasPrice * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]
                    };
                }
                break;
        }
    } else {
        switch(gasPriceSettings.model){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559:
                return {
                    maxPriorityFeePerGas: gasPriceSettings.maxPriorityFeePerGas,
                    maxFeePerGas: gasPriceSettings.maxFeePerGas
                };
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY:
                return {
                    gasPrice: gasPriceSettings.gasPrice
                };
        }
    }
};
const getFormattedGasPrice = ({ baseFee, chainId, gasPrice, gasPriceOption, gasPriceSettings })=>{
    if (gasPriceOption !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM) {
        const multiplier = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][gasPriceOption];
        switch(gasPriceSettings.model){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559:
                if (baseFee) {
                    return baseFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"];
                }
                break;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY:
                if (gasPrice) {
                    return gasPrice * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"];
                }
        }
    } else {
        switch(gasPriceSettings.model){
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559:
                return gasPriceSettings.maxFeePerGas;
            case __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY:
                return gasPriceSettings.gasPrice;
        }
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/IIFE.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "IIFE",
    ()=>IIFE
]);
const IIFE = (fn)=>{
    fn();
};
_c = IIFE;
var _c;
__turbopack_context__.k.register(_c, "IIFE");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useConvert.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useConvert,
    "useConvertEstimatedGas",
    ()=>useConvertEstimatedGas,
    "useConvertParams",
    ()=>useConvertParams
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$abi$2f$encodeFunctionData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/abi/encodeFunctionData.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/parseUnits.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useAccount.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/usePublicClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useWalletClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useWalletClient.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc223$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/abis/erc223.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/abis/tokenConverter.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/addresses.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useAllowance.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDeepEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useDeepEffect.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useGlobalFees.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertAmountStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertGasSettingsStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertStatusStore.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertTokenStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$addToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/addToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$gasSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/gasSettings.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getTransactionWithRetries$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/getTransactionWithRetries.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$IIFE$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/IIFE.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function useConvertParams() {
    _s();
    const { token, tokenStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { address } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const { typedValue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"])();
    const convertParams = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useConvertParams.useMemo[convertParams]": ()=>{
            if (!token || !chainId || !__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEX_SUPPORTED_CHAINS"].includes(chainId) || !typedValue || !address) {
                return null;
            }
            if (tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223) {
                return {
                    address: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTokenAddressForStandard"])(token, tokenStandard),
                    abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc223$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC223_ABI"],
                    functionName: "transfer",
                    args: [
                        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(typedValue, token.decimals),
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$abi$2f$encodeFunctionData$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["encodeFunctionData"])({
                            abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOKEN_CONVERTER_ABI"],
                            functionName: "convertERC20",
                            args: [
                                token.address0,
                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(typedValue, token.decimals)
                            ]
                        })
                    ]
                };
            }
            if (tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20) {
                return {
                    address: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
                    abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOKEN_CONVERTER_ABI"],
                    functionName: "convertERC20",
                    args: [
                        token.address0,
                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(typedValue, token.decimals)
                    ]
                };
            }
        }
    }["useConvertParams.useMemo[convertParams]"], [
        address,
        chainId,
        tokenStandard,
        token,
        typedValue
    ]);
    return {
        convertParams
    };
}
_s(useConvertParams, "L8lyrk4OmAFW6l2aQwi7rWQ7MkA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"]
    ];
});
function useConvertEstimatedGas() {
    _s1();
    const { address } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const { convertParams } = useConvertParams();
    const publicClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"])();
    const { setEstimatedGas } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"])();
    const { token, tokenStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { typedValue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"])();
    const { isAllowed: isAllowedA } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStoreAllowance"])({
        token: token,
        contractAddress: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
        amountToCheck: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(typedValue, token?.decimals ?? 18)
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDeepEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "useConvertEstimatedGas.useDeepEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$IIFE$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IIFE"])({
                "useConvertEstimatedGas.useDeepEffect": async ()=>{
                    if (!convertParams || !address || !isAllowedA && tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20) {
                        setEstimatedGas(BigInt(100000));
                        console.log("Can't estimate gas");
                        return;
                    }
                    try {
                        const estimated = await publicClient?.estimateContractGas({
                            account: address,
                            ...convertParams
                        });
                        if (estimated) {
                            setEstimatedGas(estimated + BigInt(10000));
                        } else {
                            setEstimatedGas(BigInt(100000));
                        }
                    // console.log(estimated);
                    } catch (e) {
                        console.log(e);
                        setEstimatedGas(BigInt(100000));
                    }
                }
            }["useConvertEstimatedGas.useDeepEffect"]);
        }
    }["useConvertEstimatedGas.useDeepEffect"], [
        publicClient,
        address,
        convertParams,
        isAllowedA
    ]);
}
_s1(useConvertEstimatedGas, "2E0KuWPtnoPgpVa4TadldALtrcA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        useConvertParams,
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStoreAllowance"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDeepEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
function useConvert() {
    _s2();
    const { data: walletClient } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useWalletClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletClient"])();
    const { token, tokenStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    const { address } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"])();
    const publicClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"])();
    useConvertEstimatedGas();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { customGasLimit, estimatedGas } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"])();
    const { gasPriceOption, gasPriceSettings } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasPriceStore"])();
    const { baseFee, priorityFee, gasPrice } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"])();
    const { typedValue } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"])();
    const { status, setStatus, setConvertHash, setApproveHash, setErrorType } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertStatusStore"])();
    const { isAllowed: isAllowedA, writeTokenApprove: approveA, updateAllowance } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStoreAllowance"])({
        token: token,
        contractAddress: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
        amountToCheck: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(typedValue, token?.decimals ?? 18)
    });
    const output = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useConvert.useMemo[output]": ()=>{
            return typedValue;
        }
    }["useConvert.useMemo[output]"], [
        typedValue
    ]);
    const { convertParams } = useConvertParams();
    const gasSettings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useConvert.useMemo[gasSettings]": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$gasSettings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getGasSettings"])({
                baseFee,
                chainId,
                gasPrice,
                priorityFee,
                gasPriceOption,
                gasPriceSettings
            });
        }
    }["useConvert.useMemo[gasSettings]"], [
        baseFee,
        chainId,
        gasPrice,
        priorityFee,
        gasPriceOption,
        gasPriceSettings
    ]);
    const handleConvert = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useConvert.useCallback[handleConvert]": async (amountToApprove)=>{
            if (!publicClient || !token) {
                return;
            }
            if (!isAllowedA && tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20) {
                setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].PENDING_APPROVE);
                const result = await approveA({
                    customAmount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(amountToApprove, token?.decimals ?? 18),
                    customGasSettings: gasSettings
                });
                if (!result?.success) {
                    setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].INITIAL);
                    return;
                } else {
                    setApproveHash(result.hash);
                    setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].LOADING_APPROVE);
                    const approveReceipt = await publicClient.waitForTransactionReceipt({
                        hash: result.hash
                    });
                    if (approveReceipt.status === "reverted") {
                        setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].ERROR_APPROVE);
                        return;
                    }
                }
            }
            if (!walletClient || !address || !token || !convertParams || typeof output == null) {
                console.log({
                    walletClient,
                    address,
                    token,
                    output,
                    publicClient,
                    chainId,
                    convertParams
                });
                return;
            }
            setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].PENDING_CONVERT);
            let hash;
            try {
                const estimatedGas = await publicClient.estimateContractGas({
                    account: address,
                    ...convertParams
                });
                const gasToUse = customGasLimit ? customGasLimit : estimatedGas + BigInt(30000); // set custom gas here if user changed it
                let _request;
                try {
                    const { request, result } = await publicClient.simulateContract({
                        ...convertParams,
                        account: address,
                        ...gasSettings,
                        gas: gasToUse
                    });
                    console.log("Swap simulation result:", result);
                    _request = request;
                } catch (e) {
                    _request = {
                        ...convertParams,
                        ...gasSettings,
                        gas: gasToUse,
                        account: undefined
                    };
                }
                hash = await walletClient.writeContract({
                    ..._request,
                    account: undefined
                });
                if (hash) {
                    setConvertHash(hash);
                    setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].LOADING_CONVERT);
                    const transaction = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getTransactionWithRetries$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getTransactionWithRetries"])({
                        hash,
                        publicClient
                    });
                    if (transaction) {
                        const receipt = await publicClient.waitForTransactionReceipt({
                            hash
                        }); //TODO: add try catch
                        updateAllowance();
                        if (receipt.status === "success") {
                            setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].SUCCESS);
                        }
                        if (receipt.status === "reverted") {
                            setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].ERROR_CONVERT);
                            const ninetyEightPercent = gasToUse * BigInt(98) / BigInt(100);
                            if (receipt.gasUsed >= ninetyEightPercent && receipt.gasUsed <= gasToUse) {
                                setErrorType(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertError"].OUT_OF_GAS);
                            } else {
                                setErrorType(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertError"].UNKNOWN);
                            }
                        }
                    }
                } else {
                    setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].INITIAL);
                }
            } catch (e) {
                console.log(e);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$addToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("Error while executing contract", "error");
                setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].INITIAL);
            }
        }
    }["useConvert.useCallback[handleConvert]"], [
        address,
        approveA,
        chainId,
        convertParams,
        customGasLimit,
        gasSettings,
        isAllowedA,
        output,
        publicClient,
        setApproveHash,
        setErrorType,
        setConvertHash,
        setStatus,
        token,
        tokenStandard,
        updateAllowance,
        walletClient
    ]);
    return {
        handleConvert,
        isAllowedA: isAllowedA,
        handleApprove: ()=>null
    };
}
_s2(useConvert, "1Lb6MEFQ24IgpSLa2B0DTeps+9A=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useWalletClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useWalletClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useAccount$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAccount"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$usePublicClient$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["usePublicClient"],
        useConvertEstimatedGas,
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasPriceStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertStatusStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStoreAllowance"],
        useConvertParams
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/factories/createDialogStateStore.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createDialogStateStore",
    ()=>createDialogStateStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/zustand/esm/react.mjs [app-client] (ecmascript)");
;
function createDialogStateStore() {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$zustand$2f$esm$2f$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["create"])((set)=>({
            isOpen: false,
            setIsOpen: (isOpen)=>set({
                    isOpen
                })
        }));
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/stores/useConfirmConvertDialogOpened.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useConfirmConvertDialogStore",
    ()=>useConfirmConvertDialogStore
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createDialogStateStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createDialogStateStore.ts [app-client] (ecmascript)");
;
const useConfirmConvertDialogStore = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createDialogStateStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createDialogStateStore"])();
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/formatFloat.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatFloat",
    ()=>formatFloat,
    "formatNumber",
    ()=>formatNumber,
    "formatNumberKilos",
    ()=>formatNumberKilos
]);
function formatFloat(value, options) {
    const numberValue = Number(value);
    const maximumSignificantDigits = options?.significantDigits ?? 2;
    if (numberValue < 1e-10) {
        if (options?.trimZero || numberValue === 0) {
            return "0";
        }
        return "< 0.0001";
    }
    if (numberValue < 1) {
        return numberValue.toLocaleString("en-US", {
            maximumSignificantDigits: maximumSignificantDigits
        });
    } else {
        const _value = numberValue.toFixed(maximumSignificantDigits);
        if (options?.trimZero) {
            return _value.replace(/(\.\d*?)0+$/, "$1").replace(/\.$/, "");
        }
        return _value;
    }
}
function formatNumber(num, maxPrecision = 15) {
    const [integerPart] = num.toString().split(".");
    if (integerPart.length >= maxPrecision) {
        // If the integer part alone exceeds or matches the precision, return it as-is
        return parseFloat(num).toPrecision(maxPrecision).replace(/\.?0+$/, "");
    } else {
        // Limit the total length to maxPrecision
        const precisionNeeded = maxPrecision - integerPart.length;
        return parseFloat(num).toPrecision(precisionNeeded).replace(/\.?0+$/, "");
    }
}
function formatNumberKilos(num, options) {
    if (num < 1000) {
        return formatFloat(num, options); // Numbers less than 1000 remain as is.
    }
    const suffixes = [
        "K",
        "M",
        "B",
        "T"
    ]; // Thousand, Million, Billion, Trillion
    let power = Math.floor(Math.log10(num) / 3); // Determine the power of 1000
    power = Math.min(power, suffixes.length); // Ensure it doesn't exceed defined suffixes
    const scaled = num / Math.pow(1000, power);
    return scaled.toFixed(options?.significantDigits ?? 2).replace(/\.0$/, "") + suffixes[power - 1];
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Preloader.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "CircularProgress",
    ()=>CircularProgress,
    "default",
    ()=>Preloader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
function Preloader({ size = 24, type = "circular", color = "green", smallDots = false }) {
    _s();
    const internalSize = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "Preloader.useMemo[internalSize]": ()=>{
            return size / Math.sqrt(2);
        }
    }["Preloader.useMemo[internalSize]"], [
        size
    ]);
    switch(type){
        case "circular":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                style: {
                    width: size,
                    height: size
                },
                className: "flex items-center justify-center relative",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        borderWidth: size > 50 ? 4 : 2
                    },
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("rounded-full border-4 border-transparent top-0 left-0 w-full h-full bg-transparent animate-spin", color === "green" && "border-t-green border-l-green border-r-green", color === "black" && "border-t-secondary-bg border-l-secondary-bg border-r-secondary-bg")
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Preloader.tsx",
                    lineNumber: 28,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Preloader.tsx",
                lineNumber: 24,
                columnNumber: 9
            }, this);
        case "linear":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-[5px]",
                style: {
                    height: size
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("block rounded-full animate-flicker1 bg-green", smallDots ? "w-[6px] h-[6px]" : "w-2 h-2 ")
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/Preloader.tsx",
                        lineNumber: 42,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("block rounded-full animate-flicker2 bg-green", smallDots ? "w-[6px] h-[6px]" : "w-2 h-2 ")
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/Preloader.tsx",
                        lineNumber: 48,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("block rounded-full animate-flicker3 bg-green", smallDots ? "w-[6px] h-[6px]" : "w-2 h-2 ")
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/Preloader.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/atoms/Preloader.tsx",
                lineNumber: 41,
                columnNumber: 9
            }, this);
        case "awaiting":
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-center",
                style: {
                    width: size,
                    height: size
                },
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    style: {
                        width: internalSize,
                        height: internalSize
                    },
                    className: `rotate-45 relative`,
                    children: [
                        0,
                        1,
                        2,
                        3,
                        4
                    ].map((v)=>{
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "absolute animate-orbit w-full h-full",
                            style: {
                                animationDelay: `${v * 100}ms`,
                                opacity: 1 - 0.2 * (v + 1),
                                zIndex: v
                            },
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                style: {
                                    width: internalSize / 5,
                                    height: internalSize / 5,
                                    boxShadow: `0px 0px ${internalSize / 2.5}px 2px #3ae374`
                                },
                                className: "absolute top-0 left-0 shadow-orbit w-[10px] h-[10px] bg-green rounded-full"
                            }, void 0, false, {
                                fileName: "[project]/app/components/atoms/Preloader.tsx",
                                lineNumber: 76,
                                columnNumber: 19
                            }, this)
                        }, v, false, {
                            fileName: "[project]/app/components/atoms/Preloader.tsx",
                            lineNumber: 71,
                            columnNumber: 17
                        }, this);
                    })
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Preloader.tsx",
                    lineNumber: 65,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Preloader.tsx",
                lineNumber: 64,
                columnNumber: 9
            }, this);
    }
}
_s(Preloader, "sUIRD4KM9e98T+sDx9ZK9fvy5bw=");
_c = Preloader;
function CircularProgress({ size = 24 }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "MuiCircularProgressIndeterminate",
        role: "progressbar",
        style: {
            width: size,
            height: size
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
            viewBox: "22 22 44 44",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("circle", {
                className: "MuiCircularProgressCircleIndeterminate stroke-green",
                cx: "44",
                cy: "44",
                r: "20.2",
                fill: "none",
                strokeWidth: "3.6"
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Preloader.tsx",
                lineNumber: 104,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/atoms/Preloader.tsx",
            lineNumber: 103,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Preloader.tsx",
        lineNumber: 95,
        columnNumber: 5
    }, this);
}
_c1 = CircularProgress;
var _c, _c1;
__turbopack_context__.k.register(_c, "Preloader");
__turbopack_context__.k.register(_c1, "CircularProgress");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/molecules/OperationStepRow.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "OperationRows",
    ()=>OperationRows,
    "OperationStepStatus",
    ()=>OperationStepStatus,
    "default",
    ()=>OperationStepRow,
    "operationStatusToStepStatus",
    ()=>operationStatusToStepStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Preloader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Preloader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/getExplorerLink.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
var OperationStepStatus = /*#__PURE__*/ function(OperationStepStatus) {
    OperationStepStatus[OperationStepStatus["IDLE"] = 0] = "IDLE";
    OperationStepStatus[OperationStepStatus["AWAITING_SIGNATURE"] = 1] = "AWAITING_SIGNATURE";
    OperationStepStatus[OperationStepStatus["LOADING"] = 2] = "LOADING";
    OperationStepStatus[OperationStepStatus["STEP_COMPLETED"] = 3] = "STEP_COMPLETED";
    OperationStepStatus[OperationStepStatus["STEP_FAILED"] = 4] = "STEP_FAILED";
    OperationStepStatus[OperationStepStatus["OPERATION_COMPLETED"] = 5] = "OPERATION_COMPLETED";
    return OperationStepStatus;
}({});
function OperationRows({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col gap-5",
        children: children
    }, void 0, false, {
        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
        lineNumber: 23,
        columnNumber: 10
    }, this);
}
_c = OperationRows;
function operationStatusToStepStatus({ currentStatus, orderedSteps, stepIndex, pendingStep, loadingStep, errorStep, successStep }) {
    if (currentStatus === successStep) {
        return 5;
    }
    if (currentStatus === errorStep) {
        return 4;
    }
    if (currentStatus === pendingStep) {
        return 1;
    }
    if (currentStatus === loadingStep) {
        return 2;
    }
    const currentGroupIndex = Math.floor(orderedSteps.indexOf(currentStatus) / 3);
    if (currentGroupIndex > stepIndex) {
        return 3;
    }
    if (currentGroupIndex < stepIndex) {
        return 0;
    }
    return 0;
}
function OperationStepRow({ status, statusTextMap, hash, iconName, isFirstStep }) {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const text = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OperationStepRow.useMemo[text]": ()=>{
            return statusTextMap[status];
        }
    }["OperationStepRow.useMemo[text]"], [
        status,
        statusTextMap
    ]);
    const isDisabled = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OperationStepRow.useMemo[isDisabled]": ()=>status === 0
    }["OperationStepRow.useMemo[isDisabled]"], [
        status
    ]);
    const icon = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OperationStepRow.useMemo[icon]": ()=>{
            switch(status){
                case 4:
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: "text-red-light",
                        iconName: "warning",
                        size: 20
                    }, void 0, false, {
                        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                        lineNumber: 95,
                        columnNumber: 16
                    }, this);
                case 2:
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Preloader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        size: 20
                    }, void 0, false, {
                        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                        lineNumber: 97,
                        columnNumber: 16
                    }, this);
                case 1:
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Preloader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                type: "linear"
                            }, void 0, false, {
                                fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                                lineNumber: 101,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-secondary-text text-14",
                                children: "Proceed in your wallet"
                            }, void 0, false, {
                                fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                                lineNumber: 102,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true);
                case 3:
                case 5:
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: "text-green",
                        iconName: "done",
                        size: 20
                    }, void 0, false, {
                        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                        lineNumber: 107,
                        columnNumber: 16
                    }, this);
                default:
                    return null;
            }
        }
    }["OperationStepRow.useMemo[icon]"], [
        status
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "grid grid-cols-[32px_auto_1fr] gap-2 h-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center h-full",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("p-1 rounded-full h-8 w-8 relative", isDisabled ? "bg-tertiary-bg" : "bg-green-bg", status === 4 && "bg-red-bg", !isFirstStep && "before:absolute before:rounded-5 before:-top-2 before:left-1/2 before:w-0.5 before:h-3 before:-translate-x-1/2 before:-translate-y-full", [
                        5,
                        1,
                        2
                    ].includes(status) ? "before:bg-green" : "before:bg-[#3C4C4A]", status === 3 && "opacity-50"),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])(isDisabled ? "text-tertiary-text" : "text-green", status === 4 && "text-red-light"),
                        iconName: iconName
                    }, void 0, false, {
                        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                        lineNumber: 133,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                    lineNumber: 116,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                lineNumber: 115,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col justify-center",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-14", isDisabled || status === 3 ? "text-tertiary-text" : "text-primary-text"),
                    children: text
                }, void 0, false, {
                    fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                    lineNumber: 144,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                lineNumber: 143,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-2 justify-end",
                children: [
                    hash && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                        target: "_blank",
                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExplorerLinkType"].TRANSACTION, hash, chainId),
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            iconName: "forward"
                        }, void 0, false, {
                            fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                            lineNumber: 158,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                        lineNumber: 157,
                        columnNumber: 11
                    }, this),
                    icon
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
                lineNumber: 155,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/molecules/OperationStepRow.tsx",
        lineNumber: 114,
        columnNumber: 5
    }, this);
}
_s(OperationStepRow, "ZM7330FUKrVM9EpQHbAlXcAtQ8Q=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c1 = OperationStepRow;
var _c, _c1;
__turbopack_context__.k.register(_c, "OperationRows");
__turbopack_context__.k.register(_c1, "OperationStepRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/utils/getStepTexts.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getApproveTextMap",
    ()=>getApproveTextMap,
    "getTransferTextMap",
    ()=>getTransferTextMap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/molecules/OperationStepRow.tsx [app-client] (ecmascript)");
;
function getApproveTextMap(tokenSymbol) {
    return {
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].IDLE]: `Approve ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].AWAITING_SIGNATURE]: `Approve ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].LOADING]: `Approving ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].STEP_COMPLETED]: `Approved ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].STEP_FAILED]: `Approve ${tokenSymbol} failed`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].OPERATION_COMPLETED]: `Approved ${tokenSymbol}`
    };
}
function getTransferTextMap(tokenSymbol) {
    return {
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].IDLE]: `Transfer ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].AWAITING_SIGNATURE]: `Transfer ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].LOADING]: `Transferring ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].STEP_COMPLETED]: `Transferred ${tokenSymbol}`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].STEP_FAILED]: `${tokenSymbol} transfer failed`,
        [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].OPERATION_COMPLETED]: `Transferred ${tokenSymbol}`
    };
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Tooltip
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/react-dom/dist/floating-ui.react-dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/dom/dist/floating-ui.dom.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@floating-ui/react/dist/floating-ui.react.mjs [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
function Tooltip({ text, iconSize = 24, renderTrigger, customOffset }) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const arrowRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { refs, floatingStyles, context } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"])({
        open: isOpen,
        onOpenChange: setIsOpen,
        placement: "top",
        // Make sure the tooltip stays on the screen
        whileElementsMounted: __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$dom$2f$dist$2f$floating$2d$ui$2e$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["autoUpdate"],
        middleware: [
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["offset"])(customOffset || 12),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["shift"])({
                padding: 10
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["flip"])({
                fallbackAxisSideDirection: "start"
            }),
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2d$dom$2f$dist$2f$floating$2d$ui$2e$react$2d$dom$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["arrow"])({
                element: arrowRef
            })
        ]
    });
    const { isMounted, styles: transitionStyles } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTransitionStyles"])(context, {
        duration: {
            open: 200,
            close: 200
        }
    });
    // Event listeners to change the open state
    const hover = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useHover"])(context, {
        move: false
    });
    const focus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFocus"])(context);
    const dismiss = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDismiss"])(context);
    // Role props for screen readers
    const role = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useRole"])(context, {
        role: "tooltip"
    });
    // Merge all the interactions into prop getters
    const { getReferenceProps, getFloatingProps } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"])([
        hover,
        focus,
        dismiss,
        role
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            renderTrigger ? renderTrigger(refs, getReferenceProps()) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "cursor-pointer text-tertiary-text pointer-events-auto",
                ref: refs.setReference,
                ...getReferenceProps(),
                onClick: (e)=>e.stopPropagation(),
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    iconName: "info",
                    size: iconSize
                }, void 0, false, {
                    fileName: "[project]/app/components/atoms/Tooltip.tsx",
                    lineNumber: 90,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Tooltip.tsx",
                lineNumber: 84,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FloatingPortal"], {
                children: isMounted && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "py-2 px-5 bg-quaternary-bg border border-secondary-border rounded-2 max-w-[400px] relative z-[100] text-14 text-secondary-text",
                    ref: refs.setFloating,
                    style: {
                        ...floatingStyles,
                        ...transitionStyles
                    },
                    ...getFloatingProps(),
                    children: [
                        text,
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["FloatingArrow"], {
                            ref: arrowRef,
                            context: context,
                            strokeWidth: 1,
                            stroke: "#383C3A",
                            fill: "#2E2F2F"
                        }, void 0, false, {
                            fileName: "[project]/app/components/atoms/Tooltip.tsx",
                            lineNumber: 102,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/atoms/Tooltip.tsx",
                    lineNumber: 95,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Tooltip.tsx",
                lineNumber: 93,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(Tooltip, "2eNeQuHjnxSMsMEp077mauMowwo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFloating"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useTransitionStyles"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useHover"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useFocus"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useDismiss"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useRole"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$floating$2d$ui$2f$react$2f$dist$2f$floating$2d$ui$2e$react$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useInteractions"]
    ];
});
_c = Tooltip;
var _c;
__turbopack_context__.k.register(_c, "Tooltip");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/organisms/SwapDetailsRow.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SwapDetailsRow
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
;
;
function SwapDetailsRow({ title, value, tooltipText }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-between items-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-1 items-center text-secondary-text",
                children: [
                    tooltipText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        iconSize: 20,
                        text: tooltipText
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/SwapDetailsRow.tsx",
                        lineNumber: 17,
                        columnNumber: 25
                    }, this),
                    title
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/SwapDetailsRow.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: value
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/SwapDetailsRow.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/organisms/SwapDetailsRow.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
_c = SwapDetailsRow;
var _c;
__turbopack_context__.k.register(_c, "SwapDetailsRow");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/organisms/ConfirmConvertDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ReadonlyTokenAmountCard",
    ()=>ReadonlyTokenAmountCard,
    "default",
    ()=>ConfirmConvertDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$number$2d$format$2f$dist$2f$react$2d$number$2d$format$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-number-format/dist/react-number-format.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/formatGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/parseUnits.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Badge.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DialogHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/DialogHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DrawerDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/DrawerDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/addresses.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useAllowance.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useConvert$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useConvert.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useGlobalFees.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConfirmConvertDialogOpened$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConfirmConvertDialogOpened.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertAmountStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertGasSettingsStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertStatusStore.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertTokenStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/formatFloat.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getStepTexts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/getStepTexts.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/molecules/OperationStepRow.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$SwapDetailsRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/organisms/SwapDetailsRow.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function composeConvertSteps({ assetStandard, assetSymbol }) {
    const approveStep = {
        iconName: "done",
        pending: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].PENDING_APPROVE,
        loading: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].LOADING_APPROVE,
        error: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].ERROR_APPROVE,
        textMap: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getStepTexts$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getApproveTextMap"])(assetSymbol || "Unknown")
    };
    const convertStep = {
        iconName: "swap",
        pending: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].PENDING_CONVERT,
        loading: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].LOADING_CONVERT,
        error: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].ERROR_CONVERT,
        textMap: {
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].IDLE]: "Margin swap",
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].AWAITING_SIGNATURE]: "Margin swap",
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].LOADING]: "Processing margin swap",
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].STEP_COMPLETED]: "Margin swap completed",
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].STEP_FAILED]: "Failed to process margin swap",
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationStepStatus"].OPERATION_COMPLETED]: "Margin swap completed"
        }
    };
    if (assetStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20) {
        return [
            approveStep,
            convertStep
        ];
    } else {
        return [
            convertStep
        ];
    }
}
function ConvertActionButton({ disabled, amountToApprove }) {
    _s();
    const { handleConvert } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useConvert$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { token, tokenStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    const { status, approveHash, convertHash } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertStatusStore"])();
    const hashes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ConvertActionButton.useMemo[hashes]": ()=>{
            if (tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20) {
                return [
                    approveHash,
                    convertHash
                ];
            }
            return [
                convertHash
            ];
        }
    }["ConvertActionButton.useMemo[hashes]"], [
        convertHash,
        approveHash,
        tokenStandard
    ]);
    if (status !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].INITIAL) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["OperationRows"], {
            children: composeConvertSteps({
                assetStandard: tokenStandard,
                assetSymbol: token?.symbol || "Unknown"
            }).map((step, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    iconName: step.iconName,
                    hash: hashes[index],
                    statusTextMap: step.textMap,
                    status: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$molecules$2f$OperationStepRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["operationStatusToStepStatus"])({
                        currentStatus: status,
                        orderedSteps: composeConvertSteps({
                            assetStandard: tokenStandard,
                            assetSymbol: token?.symbol || "Unknown"
                        }).flatMap((s)=>[
                                s.pending,
                                s.loading,
                                s.error
                            ]),
                        stepIndex: index,
                        pendingStep: step.pending,
                        loadingStep: step.loading,
                        errorStep: step.error,
                        successStep: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].SUCCESS
                    }),
                    isFirstStep: index === 0
                }, index, false, {
                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                    lineNumber: 116,
                    columnNumber: 11
                }, this))
        }, void 0, false, {
            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
            lineNumber: 111,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        disabled: disabled,
        onClick: ()=>handleConvert(amountToApprove),
        fullWidth: true,
        children: "Confirm conversion"
    }, void 0, false, {
        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
        lineNumber: 141,
        columnNumber: 5
    }, this);
}
_s(ConvertActionButton, "yKrGCKoCPkKJOTBphzEYWeNI7AA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useConvert$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertStatusStore"]
    ];
});
_c = ConvertActionButton;
function ReadonlyTokenAmountCard({ token, amount, amountUSD, standard, title }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-3 bg-tertiary-bg py-4 px-5 flex flex-col gap-1",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-secondary-text text-14",
                children: title
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                lineNumber: 162,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between items-center text-20",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        children: amount
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                        lineNumber: 164,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: token?.logoURI || "/images/tokens/placeholder.svg",
                                alt: "",
                                width: 32,
                                height: 32
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                lineNumber: 166,
                                columnNumber: 11
                            }, this),
                            token?.symbol,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                variant: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Badge$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["BadgeVariant"].STANDARD,
                                standard: standard
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                lineNumber: 173,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                        lineNumber: 165,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                lineNumber: 163,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-secondary-text text-14",
                children: [
                    "$",
                    amountUSD
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                lineNumber: 176,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
        lineNumber: 161,
        columnNumber: 5
    }, this);
}
_c1 = ReadonlyTokenAmountCard;
function ConfirmConvertDialog() {
    _s1();
    const { token, tokenStandard, reset } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    const { typedValue, reset: resetAmounts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"])();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { isOpen, setIsOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConfirmConvertDialogOpened$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfirmConvertDialogStore"])();
    const { status, setStatus } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertStatusStore"])();
    const isInitialStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ConfirmConvertDialog.useMemo[isInitialStatus]": ()=>status === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].INITIAL
    }["ConfirmConvertDialog.useMemo[isInitialStatus]"], [
        status
    ]);
    const isFinalStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ConfirmConvertDialog.useMemo[isFinalStatus]": ()=>status === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].SUCCESS || status === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].ERROR_CONVERT || status === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].ERROR_APPROVE
    }["ConfirmConvertDialog.useMemo[isFinalStatus]"], [
        status
    ]);
    const isLoadingStatus = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ConfirmConvertDialog.useMemo[isLoadingStatus]": ()=>!isInitialStatus && !isFinalStatus
    }["ConfirmConvertDialog.useMemo[isLoadingStatus]"], [
        isFinalStatus,
        isInitialStatus
    ]);
    const { estimatedGas, customGasLimit } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"])();
    const [amountToApprove, setAmountToApprove] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(typedValue);
    // const { gasOption, gasPrice, gasLimit } = useSwapGasSettingsStore();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConfirmConvertDialog.useEffect": ()=>{
            if (typedValue) {
                setAmountToApprove(typedValue);
            }
        }
    }["ConfirmConvertDialog.useEffect"], [
        typedValue
    ]);
    const { gasPriceSettings } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasPriceStore"])();
    const { baseFee } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"])();
    const computedGasSpending = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ConfirmConvertDialog.useMemo[computedGasSpending]": ()=>{
            if (gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY && gasPriceSettings.gasPrice) {
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(gasPriceSettings.gasPrice));
            }
            if (gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 && gasPriceSettings.maxFeePerGas && gasPriceSettings.maxPriorityFeePerGas && baseFee) {
                const lowerFeePerGas = gasPriceSettings.maxFeePerGas > baseFee ? baseFee : gasPriceSettings.maxFeePerGas;
                return (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(lowerFeePerGas + gasPriceSettings.maxPriorityFeePerGas));
            }
            return "0";
        }
    }["ConfirmConvertDialog.useMemo[computedGasSpending]"], [
        baseFee,
        gasPriceSettings
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ConfirmConvertDialog.useEffect": ()=>{
            if (isFinalStatus && !isOpen) {
                setTimeout({
                    "ConfirmConvertDialog.useEffect": ()=>{
                        setStatus(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ConvertStatus"].INITIAL);
                    }
                }["ConfirmConvertDialog.useEffect"], 400);
            }
        }
    }["ConfirmConvertDialog.useEffect"], [
        isFinalStatus,
        isOpen,
        setStatus
    ]);
    const [isEditApproveActive, setEditApproveActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { isAllowed: isAllowedA } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStoreAllowance"])({
        token: token,
        contractAddress: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
        amountToCheck: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseUnits$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseUnits"])(typedValue, token?.decimals ?? 18)
    });
    // const { price: priceA } = useUSDPrice(tokenA?.wrapped.address0);
    // const { price: priceNative } = useUSDPrice(wrappedTokens[chainId]?.address0);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DrawerDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        isOpen: isOpen,
        setIsOpen: (isOpen)=>{
            setIsOpen(isOpen);
        },
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "bg-primary-bg rounded-5 w-full sm:w-[600px]",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DialogHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    onClose: ()=>{
                        setIsOpen(false);
                    },
                    title: "Review conversion"
                }, void 0, false, {
                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                    lineNumber: 265,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "card-spacing",
                    children: [
                        isInitialStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ReadonlyTokenAmountCard, {
                                        token: token,
                                        amount: typedValue,
                                        amountUSD: "",
                                        standard: tokenStandard,
                                        title: "You convert"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                        lineNumber: 275,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ReadonlyTokenAmountCard, {
                                        token: token,
                                        amount: typedValue,
                                        amountUSD: "",
                                        standard: tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223 : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20,
                                        title: "You receive"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                        lineNumber: 282,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                lineNumber: 274,
                                columnNumber: 15
                            }, this)
                        }, void 0, false),
                        isLoadingStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}, void 0, false),
                        isFinalStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {}, void 0, false),
                        !isLoadingStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "pb-4 flex flex-col gap-2 rounded-b-3 text-14 mt-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$SwapDetailsRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    title: "Network fee",
                                    value: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "text-secondary-text mr-1 text-14",
                                                children: [
                                                    computedGasSpending,
                                                    " GWEI"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                lineNumber: 301,
                                                columnNumber: 21
                                            }, void 0),
                                            " ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "mr-1 text-14"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                lineNumber: 304,
                                                columnNumber: 21
                                            }, void 0)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                        lineNumber: 300,
                                        columnNumber: 19
                                    }, void 0),
                                    tooltipText: "t(network_fee_tooltip, {networkName: networks.find((n) => n.chainId === chainId)?.name,})"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                    lineNumber: 297,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$SwapDetailsRow$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    title: "Gas limit",
                                    value: customGasLimit ? customGasLimit.toString() : (estimatedGas + BigInt(30000)).toString() || "Loading...",
                                    tooltipText: "Gas tooltip"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                    lineNumber: 314,
                                    columnNumber: 15
                                }, this),
                                tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 && !isAllowedA && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("bg-tertiary-bg rounded-3 flex items-center px-5 py-2 min-h-12 mt-2 gap-2", +amountToApprove < +typedValue && "sm:pb-[26px]"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "sm:items-center sm:justify-between sm:gap-5 flex-grow flex flex-col gap-1 sm:flex-row",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-1 text-secondary-text whitespace-nowrap sm:flex-row-reverse",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            children: "Approve amount"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                            lineNumber: 333,
                                                            columnNumber: 23
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            text: "In order to make a swap with ERC-20 token you need to give the DEX contract permission to withdraw your tokens. All DEX'es require this operation. Here you are specifying the amount of tokens that you allow the contract to transfer on your behalf. Note that this amount never expires."
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                            lineNumber: 334,
                                                            columnNumber: 23
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                    lineNumber: 332,
                                                    columnNumber: 21
                                                }, this),
                                                !isEditApproveActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        amountToApprove,
                                                        " ",
                                                        token?.symbol || "Unknown"
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                    lineNumber: 342,
                                                    columnNumber: 23
                                                }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex-grow",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "relative w-full flex-grow",
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$number$2d$format$2f$dist$2f$react$2d$number$2d$format$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NumericFormat"], {
                                                                    inputMode: "decimal",
                                                                    allowedDecimalSeparators: [
                                                                        ","
                                                                    ],
                                                                    isError: +amountToApprove < +typedValue,
                                                                    className: "h-8 pl-3",
                                                                    value: amountToApprove,
                                                                    onValueChange: (values)=>{
                                                                        setAmountToApprove(values.value);
                                                                    },
                                                                    customInput: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                                                                    allowNegative: false,
                                                                    type: "text"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                                    lineNumber: 348,
                                                                    columnNumber: 27
                                                                }, this),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: "pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-tertiary-text",
                                                                    children: token?.symbol || "Unknown"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                                    lineNumber: 361,
                                                                    columnNumber: 27
                                                                }, this)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                            lineNumber: 347,
                                                            columnNumber: 25
                                                        }, this),
                                                        +amountToApprove < +typedValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-red-light sm:absolute text-12 sm:translate-y-0.5",
                                                            children: [
                                                                "Must be higher or equal ",
                                                                typedValue
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                            lineNumber: 366,
                                                            columnNumber: 27
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                    lineNumber: 346,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                            lineNumber: 331,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center",
                                            children: !isEditApproveActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                size: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].EXTRA_SMALL,
                                                mobileSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].SMALL,
                                                colorScheme: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonColor"].LIGHT_GREEN,
                                                onClick: ()=>setEditApproveActive(true),
                                                className: "!rounded-20",
                                                children: "Edit"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                lineNumber: 376,
                                                columnNumber: 23
                                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                disabled: +amountToApprove < +typedValue,
                                                size: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].EXTRA_SMALL,
                                                mobileSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonSize"].SMALL,
                                                colorScheme: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonColor"].LIGHT_GREEN,
                                                onClick: ()=>setEditApproveActive(false),
                                                className: "!rounded-20 disabled:bg-quaternary-bg",
                                                children: "Save"
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                                lineNumber: 386,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                            lineNumber: 374,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                                    lineNumber: 325,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                            lineNumber: 296,
                            columnNumber: 13
                        }, this),
                        isLoadingStatus && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-px w-full bg-secondary-border mb-4 mt-5"
                        }, void 0, false, {
                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                            lineNumber: 402,
                            columnNumber: 31
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ConvertActionButton, {
                            disabled: isEditApproveActive,
                            amountToApprove: amountToApprove
                        }, void 0, false, {
                            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                            lineNumber: 403,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
                    lineNumber: 271,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
            lineNumber: 264,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/organisms/ConfirmConvertDialog.tsx",
        lineNumber: 258,
        columnNumber: 5
    }, this);
}
_s1(ConfirmConvertDialog, "ezsklyWB+lSsyMmCgpwqURKM+J4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConfirmConvertDialogOpened$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfirmConvertDialogStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertStatusStore$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertStatusStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasPriceStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useAllowance$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useStoreAllowance"]
    ];
});
_c2 = ConfirmConvertDialog;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "ConvertActionButton");
__turbopack_context__.k.register(_c1, "ReadonlyTokenAmountCard");
__turbopack_context__.k.register(_c2, "ConfirmConvertDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/TextField.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "HelperText",
    ()=>HelperText,
    "InputLabel",
    ()=>InputLabel,
    "default",
    ()=>TextField
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$number$2d$format$2f$dist$2f$react$2d$number$2d$format$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-number-format/dist/react-number-format.es.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
;
;
;
;
;
const inputLabelSizeMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].DEFAULT]: "text-14",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].LARGE]: "text-16"
};
function InputLabel({ label, tooltipText, inputSize = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].DEFAULT, noMargin = false, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("font-bold flex items-center gap-1 text-secondary-text", props.disabled && "opacity-50", inputLabelSizeMap[inputSize], !noMargin && "mb-1"),
        children: [
            label,
            tooltipText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                iconSize: 20,
                text: tooltipText
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 64,
                columnNumber: 23
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/TextField.tsx",
        lineNumber: 55,
        columnNumber: 5
    }, this);
}
_c = InputLabel;
function HelperText({ helperText, error, warning, disabled }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "text-12 mt-1 min-h-4",
        children: [
            typeof helperText !== "undefined" && !error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-12 text-tertiary-text h-4", disabled && "opacity-50"),
                children: helperText
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 78,
                columnNumber: 9
            }, this),
            typeof error !== "undefined" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-12 text-red-light h-4 mt-1",
                children: error
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 82,
                columnNumber: 40
            }, this),
            warning && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-12 text-orange mt-1 h-4",
                children: warning
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 83,
                columnNumber: 19
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/TextField.tsx",
        lineNumber: 76,
        columnNumber: 5
    }, this);
}
_c1 = HelperText;
function TextField({ label, helperText, error, warning, tooltipText, variant = "default", internalText, isError = false, isWarning = false, inputSize = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].LARGE, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(InputLabel, {
                inputSize: inputSize,
                label: label,
                tooltipText: tooltipText
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 103,
                columnNumber: 7
            }, this),
            variant === "default" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    props.isNumeric ? (()=>{
                        const { isNumeric, ...rest } = props;
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$number$2d$format$2f$dist$2f$react$2d$number$2d$format$2e$es$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NumericFormat"], {
                                inputMode: "decimal",
                                allowedDecimalSeparators: [
                                    ","
                                ],
                                isError: Boolean(error) || isError,
                                isWarning: Boolean(warning) || isWarning,
                                customInput: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
                                inputSize: inputSize,
                                ...rest
                            }, void 0, false, {
                                fileName: "[project]/app/components/atoms/TextField.tsx",
                                lineNumber: 111,
                                columnNumber: 19
                            }, this)
                        }, void 0, false);
                    })() : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        isError: Boolean(error) || isError,
                        isWarning: Boolean(warning) || isWarning,
                        ...props
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/TextField.tsx",
                        lineNumber: 124,
                        columnNumber: 13
                    }, this),
                    internalText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute right-5 text-tertiary-text top-1/2 -translate-y-1/2",
                        children: internalText
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/TextField.tsx",
                        lineNumber: 131,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 105,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchInput"], {
                isError: Boolean(error),
                isWarning: Boolean(warning),
                ...props
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 137,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HelperText, {
                helperText: helperText,
                error: error,
                warning: warning,
                disabled: props.disabled
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextField.tsx",
                lineNumber: 140,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/TextField.tsx",
        lineNumber: 102,
        columnNumber: 5
    }, this);
}
_c2 = TextField;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "InputLabel");
__turbopack_context__.k.register(_c1, "HelperText");
__turbopack_context__.k.register(_c2, "TextField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Alert.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Alert
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
;
;
const iconsMap = {
    success: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        iconName: "success",
        className: "flex-shrink-0"
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Alert.tsx",
        lineNumber: 17,
        columnNumber: 12
    }, ("TURBOPACK compile-time value", void 0)),
    info: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        iconName: "info",
        className: "flex-shrink-0"
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Alert.tsx",
        lineNumber: 18,
        columnNumber: 9
    }, ("TURBOPACK compile-time value", void 0)),
    error: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        iconName: "warning",
        className: "flex-shrink-0"
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Alert.tsx",
        lineNumber: 19,
        columnNumber: 10
    }, ("TURBOPACK compile-time value", void 0)),
    warning: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        iconName: "warning",
        className: "flex-shrink-0"
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Alert.tsx",
        lineNumber: 20,
        columnNumber: 12
    }, ("TURBOPACK compile-time value", void 0)),
    "info-border": /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        iconName: "info",
        className: "flex-shrink-0"
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/Alert.tsx",
        lineNumber: 21,
        columnNumber: 18
    }, ("TURBOPACK compile-time value", void 0))
};
function Alert({ text, type = "success", withIcon = true, className = "" }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])(`
        relative
        flex
        outline
        rounded-2
        gap-2
        px-4
        md:px-5
        py-2
        overflow-hidden
        group
        text-14
        text-secondary-text
        `, type === "success" && "outline-green bg-green-bg outline-1", type === "error" && "outline-red-light bg-red-bg outline-1", type === "warning" && "outline-orange bg-orange-bg outline-1", type === "info" && "outline-blue bg-blue-bg outline-1", type === "info-border" && "border-l-4 border-l-blue outline-0 bg-primary-bg pl-4", className),
        children: [
            withIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex justify-center flex-shrink-0 items-stretch", type === "success" && "text-green", type === "error" && "text-red-light", type === "warning" && "text-orange", type === "info" && "text-blue", type === "info-border" && "text-blue"),
                children: iconsMap[type]
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Alert.tsx",
                lineNumber: 51,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center",
                children: text
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Alert.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/Alert.tsx",
        lineNumber: 26,
        columnNumber: 5
    }, this);
}
_c = Alert;
var _c;
__turbopack_context__.k.register(_c, "Alert");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/Switch.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Switch
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
;
;
var ThemeColors = /*#__PURE__*/ function(ThemeColors) {
    ThemeColors[ThemeColors["GREEN"] = 0] = "GREEN";
    ThemeColors[ThemeColors["PURPLE"] = 1] = "PURPLE";
    return ThemeColors;
}(ThemeColors || {});
function Switch({ checked, handleChange, small = false, disabled = false, colorScheme = 0 }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("relative inline-block w-12 h-6"),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                className: "peer appearance-none",
                disabled: disabled,
                checked: checked,
                onChange: handleChange,
                type: "checkbox"
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Switch.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(`
          bg-secondary-bg
                      absolute
                      cursor-pointer
                      w-full
                      h-full
                      top-0
                      bottom-0
                      right-0
                      left-0
                      duration-200
                      peer-checked:hover:shadow
                      border-primary-border
                      border
                      rounded-5
                      peer-checked:before:translate-x-6
                      before:content-['']
                      before:absolute
                      before:top-[2px]
                      before:left-[2px]
                      before:h-[18px]
                      before:w-[18px]
                      before:bg-primary-border
                      before:rounded-full
                      before:duration-200
                  `, {
                    [0]: "peer-hover:before:bg-green peer-checked:before:bg-green peer-hover:border-green peer-checked:border-green peer-checked:bg-green-bg peer-checked:hover:shadow-green/60",
                    [1]: "peer-hover:before:bg-purple peer-checked:before:bg-purple peer-hover:border-purple peer-checked:border-purple peer-checked:bg-purple-bg peer-checked:hover:shadow-purple/60"
                }[colorScheme])
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/Switch.tsx",
                lineNumber: 33,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/Switch.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c = Switch;
var _c;
__turbopack_context__.k.register(_c, "Switch");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/TextButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TextButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/theme-colors.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/clsxMerge.ts [app-client] (ecmascript)");
;
;
;
;
function TextButton({ colorScheme = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN, endIcon, children, className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$clsxMerge$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["clsxMerge"])("disabled:opacity-50 disabled:pointer-events-none disabled:text-tertiary-text rounded-2 flex items-center justify-center gap-2 px-6 duration-200", "text-secondary-text ", {
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].GREEN]: "hover:text-green-hover",
            [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].PURPLE]: "hover:text-purple-hover"
        }[colorScheme], className),
        ...props,
        children: [
            children,
            endIcon && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                iconName: endIcon
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TextButton.tsx",
                lineNumber: 34,
                columnNumber: 19
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/TextButton.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_c = TextButton;
var _c;
__turbopack_context__.k.register(_c, "TextButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/ConfigureAutomatically.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConfigureAutomatically
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/formatGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/TextButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/baseFeeMultipliers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/theme-colors.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useGlobalFees.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
function ConfigureAutomatically({ gasPriceModel, setFieldValue }) {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { baseFee, priorityFee, gasPrice } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"])();
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex justify-between items-center pb-3 pt-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "hidden text-tertiary-text md:inline",
                    children: "Custom gas settings"
                }, void 0, false, {
                    fileName: "[project]/app/components/gas-settings/ConfigureAutomatically.tsx",
                    lineNumber: 23,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/ConfigureAutomatically.tsx",
                lineNumber: 22,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                colorScheme: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$theme$2d$colors$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ThemeColors"].PURPLE,
                onClick: ()=>{
                    const multiplier = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP];
                    if (gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559) {
                        if (baseFee) {
                            setFieldValue("maxFeePerGas", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(baseFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]));
                        }
                        if (priorityFee) {
                            setFieldValue("maxPriorityFeePerGas", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(priorityFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]));
                        }
                    }
                    if (gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY) {
                        if (gasPrice) {
                            setFieldValue("gasPrice", (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(gasPrice * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]));
                        }
                    }
                },
                type: "reset",
                endIcon: "reset",
                className: "pr-0",
                children: "Configure automatically"
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/ConfigureAutomatically.tsx",
                lineNumber: 25,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/gas-settings/ConfigureAutomatically.tsx",
        lineNumber: 21,
        columnNumber: 5
    }, this);
}
_s(ConfigureAutomatically, "e+kqbAD7g3VC4aHia+vU1kh9+rU=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"]
    ];
});
_c = ConfigureAutomatically;
var _c;
__turbopack_context__.k.register(_c, "ConfigureAutomatically");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/ErrorsAndWarnings.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ErrorsAndWarnings
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Alert.tsx [app-client] (ecmascript)");
;
;
function ErrorsAndWarnings({ errors, warnings }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: (!!errors?.length || !!warnings?.length) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-5 mt-4",
            children: [
                errors?.map((err)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        text: err,
                        type: "error"
                    }, err, false, {
                        fileName: "[project]/app/components/gas-settings/ErrorsAndWarnings.tsx",
                        lineNumber: 17,
                        columnNumber: 13
                    }, this)),
                warnings?.map((war)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        text: war,
                        type: "warning"
                    }, war, false, {
                        fileName: "[project]/app/components/gas-settings/ErrorsAndWarnings.tsx",
                        lineNumber: 20,
                        columnNumber: 13
                    }, this))
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/gas-settings/ErrorsAndWarnings.tsx",
            lineNumber: 15,
            columnNumber: 9
        }, this)
    }, void 0, false);
}
_c = ErrorsAndWarnings;
var _c;
__turbopack_context__.k.register(_c, "ErrorsAndWarnings");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/EIP1559Fields.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EIP1559Fields
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/formatGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/TextField.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ErrorsAndWarnings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/ErrorsAndWarnings.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/formatFloat.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function EIP1559Fields({ maxFeePerGas, maxPriorityFeePerGas, handleChange, handleBlur, currentMaxFeePerGas, setMaxFeePerGasValue, setMaxPriorityFeePerGasValue, currentMaxPriorityFeePerGas, maxFeePerGasError, maxFeePerGasWarning, maxPriorityFeePerGasError, maxPriorityFeePerGasWarning, helperButtonText = "Current" }) {
    _s();
    const gasPriceErrors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "EIP1559Fields.useMemo[gasPriceErrors]": ()=>{
            const _errors = [];
            [
                maxPriorityFeePerGasError,
                maxFeePerGasError
            ].forEach({
                "EIP1559Fields.useMemo[gasPriceErrors]": (v)=>{
                    if (v) {
                        _errors.push(v);
                    }
                }
            }["EIP1559Fields.useMemo[gasPriceErrors]"]);
            return _errors;
        }
    }["EIP1559Fields.useMemo[gasPriceErrors]"], [
        maxFeePerGasError,
        maxPriorityFeePerGasError
    ]);
    const gasPriceWarnings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "EIP1559Fields.useMemo[gasPriceWarnings]": ()=>{
            const _warnings = [];
            [
                maxPriorityFeePerGasWarning,
                maxFeePerGasWarning
            ].forEach({
                "EIP1559Fields.useMemo[gasPriceWarnings]": (v)=>{
                    if (v) {
                        _warnings.push(v);
                    }
                }
            }["EIP1559Fields.useMemo[gasPriceWarnings]"]);
            return _warnings;
        }
    }["EIP1559Fields.useMemo[gasPriceWarnings]"], [
        maxFeePerGasWarning,
        maxPriorityFeePerGasWarning
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "grid gap-3 grid-cols-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        isNumeric: true,
                        isError: !!maxFeePerGasError,
                        isWarning: !!maxFeePerGasWarning,
                        placeholder: "Max fee",
                        label: "Max fee",
                        name: "maxFeePerGas",
                        id: "maxFeePerGas",
                        tooltipText: "The amount of fee that you are going to pay is calculated as (baseFee + priorityFee) * gasUsed. Base fee is determined by the network load. Priority fee is determined by the sender of the transaction. Gas requirement is determined by the type of action your transaction performs.  Max fee sets the upper bound of the payment that you allow your transaction to consume in total. The transaction will not confirm until the base fee in the network is small enough to allow your transaction to submit without exceeding max fee.",
                        value: maxFeePerGas,
                        onChange: (e)=>{
                            handleChange(e);
                        },
                        onBlur: (e)=>{
                            handleBlur(e);
                        },
                        helperText: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>{
                                        if (currentMaxFeePerGas) {
                                            setMaxFeePerGasValue((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(currentMaxFeePerGas));
                                        }
                                    // setUnsavedMaxFeePerGas( || BigInt(0));
                                    },
                                    className: "text-green duration-200 hover:text-green-hover",
                                    children: helperButtonText
                                }, void 0, false, {
                                    fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                                    lineNumber: 86,
                                    columnNumber: 15
                                }, void 0),
                                " ",
                                currentMaxFeePerGas ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(currentMaxFeePerGas)) : "0",
                                " Gwei"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                            lineNumber: 85,
                            columnNumber: 13
                        }, void 0),
                        inputSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].DEFAULT
                    }, void 0, false, {
                        fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                        lineNumber: 65,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        isNumeric: true,
                        isError: !!maxPriorityFeePerGasError,
                        isWarning: !!maxPriorityFeePerGasWarning,
                        placeholder: "Priority fee",
                        label: "Priority fee",
                        name: "maxPriorityFeePerGas",
                        id: "maxPriorityFeePerGas",
                        tooltipText: "The amount of fee that you are going to pay is calculated as (baseFee + priorityFee) * gasUsed. Higher priority fee may reduce the amount of time needed for your transaction to submit if the network load is sufficiently low to satisfy the max fee criteria.",
                        value: maxPriorityFeePerGas,
                        onChange: (e)=>{
                            handleChange(e);
                        },
                        onBlur: (e)=>{
                            handleBlur(e);
                        },
                        helperText: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-1",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    type: "button",
                                    onClick: ()=>{
                                        if (currentMaxPriorityFeePerGas) {
                                            setMaxPriorityFeePerGasValue((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(currentMaxPriorityFeePerGas));
                                        }
                                    },
                                    className: "text-green duration-200 hover:text-green-hover",
                                    children: helperButtonText
                                }, void 0, false, {
                                    fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                                    lineNumber: 124,
                                    columnNumber: 15
                                }, void 0),
                                " ",
                                currentMaxPriorityFeePerGas ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(currentMaxPriorityFeePerGas)) : "0",
                                " ",
                                "Gwei"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                            lineNumber: 123,
                            columnNumber: 13
                        }, void 0),
                        inputSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].DEFAULT
                    }, void 0, false, {
                        fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                        lineNumber: 105,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                lineNumber: 64,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ErrorsAndWarnings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                errors: gasPriceErrors,
                warnings: gasPriceWarnings
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/EIP1559Fields.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(EIP1559Fields, "Fk7Oh4VAk1hGo2k9cAX1LJeHB14=");
_c = EIP1559Fields;
var _c;
__turbopack_context__.k.register(_c, "EIP1559Fields");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/GasLimitField.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GasLimitField
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/TextField.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ErrorsAndWarnings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/ErrorsAndWarnings.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
function GasLimitField({ value, setFieldValue, onChange, onBlur, estimatedGas, gasLimitError }) {
    _s();
    const gasLimitErrors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "GasLimitField.useMemo[gasLimitErrors]": ()=>{
            const _errors = [];
            [
                gasLimitError
            ].forEach({
                "GasLimitField.useMemo[gasLimitErrors]": (v)=>{
                    if (v) {
                        _errors.push(v);
                    }
                }
            }["GasLimitField.useMemo[gasLimitErrors]"]);
            return _errors;
        }
    }["GasLimitField.useMemo[gasLimitErrors]"], [
        gasLimitError
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isNumeric: true,
                decimalScale: 0,
                placeholder: "Gas limit",
                label: "Gas limit",
                name: "gasLimit",
                id: "gasLimit",
                tooltipText: "The amount of fee that you are going to pay is calculated as (baseFee + priorityFee) * gasUsed.  Gas Limit sets the upper bound for gasUsed variable in this formula. If your transaction will consume less gas than the Gas Limit then you will only pay for the gas required for your transaction to submit and the rest will be refunded.  Setting a low Gas Limit may result in transaction failure if the amount of actions triggered by this transaction require more gas than specified with Gas Limit.",
                value: value,
                onChange: onChange,
                onBlur: onBlur,
                isError: !!gasLimitError,
                helperText: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: (e)=>{
                                setFieldValue(estimatedGas ? estimatedGas.toString() : "100000");
                            },
                            className: "text-green duration-200 hover:text-green-hover",
                            children: "Estimated"
                        }, void 0, false, {
                            fileName: "[project]/app/components/gas-settings/GasLimitField.tsx",
                            lineNumber: 55,
                            columnNumber: 13
                        }, void 0),
                        " ",
                        estimatedGas ? estimatedGas?.toString() : 100000,
                        " Gwei"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/gas-settings/GasLimitField.tsx",
                    lineNumber: 54,
                    columnNumber: 11
                }, void 0),
                inputSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].DEFAULT
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/GasLimitField.tsx",
                lineNumber: 37,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ErrorsAndWarnings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                errors: gasLimitErrors
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/GasLimitField.tsx",
                lineNumber: 69,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(GasLimitField, "Jt+lTprkkX0lHeos292dy2QTvcA=");
_c = GasLimitField;
var _c;
__turbopack_context__.k.register(_c, "GasLimitField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/GasOptionRadioButton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GasOptionRadioButton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
;
;
;
;
function GasOptionRadioButton({ onClick, gasPriceGWEI, gasPriceCurrency, tooltipText, title, iconName, customContent, isActive, disabled }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        onClick: onClick,
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("w-full rounded-3 bg-tertiary-bg group cursor-pointer", isActive && "cursor-auto", disabled && "pointer-events-none"),
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex justify-between px-5 items-center min-h-12 md:min-h-[60px] duration-200", !!customContent ? "border-primary-bg rounded-t-3 border-b" : "border-primary-bg rounded-3", !isActive && "group-hover:bg-green-bg", disabled && "opacity-50"),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("w-4 h-4 duration-200 before:duration-200 border bg-secondary-bg rounded-full before:w-2.5 before:h-2.5 before:absolute before:top-1/2 before:rounded-full before:left-1/2 before:-translate-x-1/2 before:-translate-y-1/2 relative", isActive ? "border-green before:bg-green" : "border-secondary-border group-hover:border-green")
                            }, void 0, false, {
                                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                lineNumber: 50,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(isActive ? "text-green" : "text-tertiary-text group-hover:text-primary-text", "duration-200"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    iconName: iconName
                                }, void 0, false, {
                                    fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                    lineNumber: 65,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                lineNumber: 59,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col md:flex-row md:items-center md:gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(isActive ? "text-primary-text" : "text-secondary-text group-hover:text-primary-text", "duration-200 font-bold text-14 md:text-16"),
                                            children: title
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                            lineNumber: 69,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-tertiary-text",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                iconSize: 20,
                                                text: tooltipText
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                                lineNumber: 81,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                            lineNumber: 80,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                    lineNumber: 68,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                lineNumber: 67,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                        lineNumber: 49,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col items-end gap-0.5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(isActive ? "text-primary-text" : "text-secondary-text group-hover:text-primary-text", "duration-200  text-12 md:text-16"),
                                children: gasPriceCurrency
                            }, void 0, false, {
                                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                lineNumber: 97,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(isActive ? "text-tertiary-text" : "text-tertiary-text", "duration-200  text-12 md:text-14"),
                                children: gasPriceGWEI
                            }, void 0, false, {
                                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                                lineNumber: 105,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                        lineNumber: 96,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this),
            customContent
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/gas-settings/GasOptionRadioButton.tsx",
        lineNumber: 31,
        columnNumber: 5
    }, this);
}
_c = GasOptionRadioButton;
var _c;
__turbopack_context__.k.register(_c, "GasOptionRadioButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/hooks/useNetworkFeeGasValidation.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useNetworkFeeGasValidation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/parseGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useGlobalFees.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
function useNetworkFeeGasValidation({ ...values }) {
    _s();
    const { baseFee, priorityFee, gasPrice } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"])();
    const maxFeePerGasError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[maxFeePerGasError]": ()=>{
            return baseFee && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxFeePerGas) < baseFee ? "Max fee per gas is too low for current network condition" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[maxFeePerGasError]"], [
        baseFee,
        values.maxFeePerGas
    ]);
    const maxFeePerGasWarning = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[maxFeePerGasWarning]": ()=>{
            return baseFee && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxFeePerGas) > baseFee * BigInt(3) ? "Max fee per gas is unnecessarily high for current network condition" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[maxFeePerGasWarning]"], [
        baseFee,
        values.maxFeePerGas
    ]);
    const maxPriorityFeePerGasError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[maxPriorityFeePerGasError]": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxPriorityFeePerGas) === BigInt(0) ? "Max priority fee per gas is too low for current network condition" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[maxPriorityFeePerGasError]"], [
        values.maxPriorityFeePerGas
    ]);
    const maxPriorityFeePerGasWarning = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[maxPriorityFeePerGasWarning]": ()=>{
            return priorityFee && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxPriorityFeePerGas) > priorityFee * BigInt(3) ? "Max priority fee per gas is unnecessarily high for current network condition" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[maxPriorityFeePerGasWarning]"], [
        priorityFee,
        values.maxPriorityFeePerGas
    ]);
    const legacyGasPriceError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[legacyGasPriceError]": ()=>{
            return gasPrice && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.gasPrice) < gasPrice ? "Gas price is too low for current network condition" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[legacyGasPriceError]"], [
        gasPrice,
        values.gasPrice
    ]);
    const legacyGasPriceWarning = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[legacyGasPriceWarning]": ()=>{
            return gasPrice && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.gasPrice) > gasPrice * BigInt(3) ? "Gas price is unnecessarily high for current network condition" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[legacyGasPriceWarning]"], [
        gasPrice,
        values.gasPrice
    ]);
    const gasLimitError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useNetworkFeeGasValidation.useMemo[gasLimitError]": ()=>{
            return BigInt(values.gasLimit) < values.estimatedGas ? "Gas limit is lower then recommended" : undefined;
        }
    }["useNetworkFeeGasValidation.useMemo[gasLimitError]"], [
        values.gasLimit,
        values.estimatedGas
    ]);
    return {
        maxFeePerGasError,
        maxFeePerGasWarning,
        maxPriorityFeePerGasError,
        maxPriorityFeePerGasWarning,
        legacyGasPriceError,
        legacyGasPriceWarning,
        gasLimitError
    };
}
_s(useNetworkFeeGasValidation, "G/ncE87r8Sj8GAxUmaA6PEvPrGk=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/gas-settings/LegacyField.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>LegacyField
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/formatGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/TextField.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ErrorsAndWarnings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/ErrorsAndWarnings.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/formatFloat.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
function LegacyField({ value, onChange, onBlur, gasPrice, setFieldValue, legacyGasPriceError, legacyGasPriceWarning }) {
    _s();
    const legacyGasPriceErrors = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "LegacyField.useMemo[legacyGasPriceErrors]": ()=>{
            const _errors = [];
            [
                legacyGasPriceError
            ].forEach({
                "LegacyField.useMemo[legacyGasPriceErrors]": (v)=>{
                    if (v) {
                        _errors.push(v);
                    }
                }
            }["LegacyField.useMemo[legacyGasPriceErrors]"]);
            return _errors;
        }
    }["LegacyField.useMemo[legacyGasPriceErrors]"], [
        legacyGasPriceError
    ]);
    const legacyGasPriceWarnings = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "LegacyField.useMemo[legacyGasPriceWarnings]": ()=>{
            const _warnings = [];
            [
                legacyGasPriceWarning
            ].forEach({
                "LegacyField.useMemo[legacyGasPriceWarnings]": (v)=>{
                    if (v) {
                        _warnings.push(v);
                    }
                }
            }["LegacyField.useMemo[legacyGasPriceWarnings]"]);
            return _warnings;
        }
    }["LegacyField.useMemo[legacyGasPriceWarnings]"], [
        legacyGasPriceWarning
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isNumeric: true,
                placeholder: "Gas price",
                label: "Gas price",
                name: "gasPrice",
                id: "gasPrice",
                tooltipText: " The amount of fee that you are going to pay with legacy transaction is calculated as gasPrice * gasUsed.  Your transaction will not confirm until your gasPrice is higher or equal to the gas price of the network in the last block. ",
                value: value,
                onChange: onChange,
                onBlur: onBlur,
                helperText: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-1",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            type: "button",
                            onClick: ()=>{
                                if (gasPrice) {
                                    setFieldValue((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(gasPrice));
                                }
                            },
                            className: "text-green duration-200 hover:text-green-hover",
                            children: "Current"
                        }, void 0, false, {
                            fileName: "[project]/app/components/gas-settings/LegacyField.tsx",
                            lineNumber: 67,
                            columnNumber: 13
                        }, void 0),
                        " ",
                        gasPrice ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(gasPrice)) : "0",
                        " Gwei"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/gas-settings/LegacyField.tsx",
                    lineNumber: 66,
                    columnNumber: 11
                }, void 0),
                inputSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["InputSize"].DEFAULT
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/LegacyField.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ErrorsAndWarnings$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                errors: legacyGasPriceErrors,
                warnings: legacyGasPriceWarnings
            }, void 0, false, {
                fileName: "[project]/app/components/gas-settings/LegacyField.tsx",
                lineNumber: 83,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(LegacyField, "C2Eoc1d/Edev8x0Oc+agbItsHRg=");
_c = LegacyField;
var _c;
__turbopack_context__.k.register(_c, "LegacyField");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useNativeCurrency.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useNativeCurrency",
    ()=>useNativeCurrency
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/networks.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
const nativeCurrenciesMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$networks$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DexChainId"].MAINNET]: {
        symbol: "ETH",
        name: "Ethereum",
        logoURI: "/images/coins/ETH.svg"
    }
};
function useNativeCurrency() {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    return nativeCurrenciesMap[chainId];
}
_s(useNativeCurrency, "zeCpsajCO/mvbsjH2V8Hzuw4dlc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NetworkFeeConfigDialog
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$formik$2f$dist$2f$formik$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/formik/dist/formik.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$debounce$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/lodash.debounce/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatEther$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/formatEther.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/formatGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/unit/parseGwei.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Alert.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DialogHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/DialogHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DrawerDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/DrawerDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Switch.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ConfigureAutomatically$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/ConfigureAutomatically.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$EIP1559Fields$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/EIP1559Fields.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$GasLimitField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/GasLimitField.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$GasOptionRadioButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/GasOptionRadioButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$hooks$2f$useNetworkFeeGasValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/hooks/useNetworkFeeGasValidation.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$LegacyField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/gas-settings/LegacyField.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/baseFeeMultipliers.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/eip1559.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDeepEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useDeepEffect.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useGlobalFees.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useNativeCurrency$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useNativeCurrency.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/factories/createGasPriceStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$addToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/addToast.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/formatFloat.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const gasOptionTitle = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP]: "Cheaper",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].FAST]: "Faster",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM]: "Custom"
};
const gasOptionIcon = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP]: "cheap-gas",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].FAST]: "fast-gas",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM]: "custom-gas"
};
const gasOptions = [
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP,
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].FAST,
    __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM
];
function getInitialCustomValue(initialOption, estimatedValue, initialValue, chainId) {
    if (initialOption === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM && initialValue) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(initialValue);
    }
    if (estimatedValue) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(estimatedValue * __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP] / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]);
    }
    return "";
}
const tooltipTextMap = {
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP]: "GAS values will be set to minimize the fee you are going to pay. It might result in the transaction being pending for longer before confirming.",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM]: "With custom transaction configuration you can set the gas values manually.",
    [__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].FAST]: "GAS values will be set to minimize the amount of time your transaction will take to confirm. It might result in higher gas fee payment."
};
function NetworkFeeDialogContent({ isAdvanced, setIsOpen, gasPriceOption, gasPriceSettings, setGasPriceSettings, setGasPriceOption, estimatedGas, customGasLimit, setCustomGasLimit }) {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { baseFee, priorityFee, gasPrice } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDeepEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        "NetworkFeeDialogContent.useDeepEffect": ()=>{
            if (gasPriceOption === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP) {
                if (gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559) {
                    if (!gasPriceSettings.maxFeePerGas && baseFee && !gasPriceSettings.maxPriorityFeePerGas && priorityFee) {
                        const multiplier = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP];
                        setGasPriceSettings({
                            model: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559,
                            maxFeePerGas: baseFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"],
                            maxPriorityFeePerGas: priorityFee * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]
                        });
                    }
                }
                if (gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY) {
                    if (!gasPriceSettings.gasPrice && gasPrice) {
                        const multiplier = __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CHEAP];
                        setGasPriceSettings({
                            model: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY,
                            gasPrice: gasPrice * multiplier / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"]
                        });
                    }
                }
            }
        }
    }["NetworkFeeDialogContent.useDeepEffect"], [
        baseFee,
        priorityFee
    ]);
    const handleApply = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NetworkFeeDialogContent.useCallback[handleApply]": (args)=>{
            if ((!baseFee || !priorityFee) && !gasPrice) {
                return;
            }
            const { option } = args;
            setGasPriceOption(option);
            if (option === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM) {
                setGasPriceSettings(args.gasSettings);
            }
        }
    }["NetworkFeeDialogContent.useCallback[handleApply]"], [
        baseFee,
        gasPrice,
        priorityFee,
        setGasPriceOption,
        setGasPriceSettings
    ]);
    const handleCancel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NetworkFeeDialogContent.useCallback[handleCancel]": ()=>{
            setIsOpen(false);
        }
    }["NetworkFeeDialogContent.useCallback[handleCancel]"], [
        setIsOpen
    ]);
    const [isInitialized, setIsInitialized] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NetworkFeeDialogContent.useEffect": ()=>{
            if (baseFee && priorityFee && gasPrice) {
                if (gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 && gasPriceSettings.maxFeePerGas && gasPriceSettings.maxPriorityFeePerGas) {
                    setIsInitialized(true);
                }
                if (gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY && gasPriceSettings.gasPrice) {
                    setIsInitialized(true);
                }
            }
        }
    }["NetworkFeeDialogContent.useEffect"], [
        gasPrice,
        priorityFee,
        baseFee,
        gasPriceSettings
    ]);
    const nativeCurrency = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useNativeCurrency$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNativeCurrency"])();
    const formik = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$formik$2f$dist$2f$formik$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormik"])({
        enableReinitialize: !isInitialized,
        initialValues: {
            maxFeePerGas: getInitialCustomValue(gasPriceOption, baseFee, gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 ? gasPriceSettings.maxFeePerGas : undefined, chainId),
            maxPriorityFeePerGas: getInitialCustomValue(gasPriceOption, priorityFee, gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 ? gasPriceSettings.maxPriorityFeePerGas : undefined, chainId),
            gasPrice: getInitialCustomValue(gasPriceOption, gasPrice, gasPriceSettings.model === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY ? gasPriceSettings.gasPrice : undefined, chainId),
            gasPriceOption,
            gasPriceModel: gasPriceSettings.model,
            gasLimit: customGasLimit ? customGasLimit.toString() : estimatedGas.toString()
        },
        onSubmit: {
            "NetworkFeeDialogContent.useFormik[formik]": (values, formikHelpers)=>{
                if (values.gasPriceOption !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM) {
                    handleApply({
                        option: values.gasPriceOption
                    });
                } else {
                    // Gas Option CUSTOM
                    if (values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559) {
                        //  || !isAdvanced   // TODO why it is here?
                        // if (!isAdvanced) {
                        handleApply({
                            option: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM,
                            gasSettings: {
                                model: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559,
                                maxFeePerGas: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxFeePerGas),
                                maxPriorityFeePerGas: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxPriorityFeePerGas)
                            },
                            gasLimit: BigInt(values.gasLimit)
                        });
                    // }
                    } else {
                        // if (!isAdvanced) {
                        if (values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY) {
                            handleApply({
                                option: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM,
                                gasSettings: {
                                    model: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY,
                                    gasPrice: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.gasPrice)
                                },
                                gasLimit: BigInt(values.gasLimit)
                            });
                        }
                    // }
                    }
                    if (isAdvanced) {
                        setCustomGasLimit(BigInt(values.gasLimit));
                    }
                }
                setIsOpen(false);
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$addToast$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("Settings applied");
            }
        }["NetworkFeeDialogContent.useFormik[formik]"]
    });
    const { handleChange, handleBlur, touched, values, setFieldValue, handleSubmit, handleReset } = formik;
    const { maxFeePerGasError, maxFeePerGasWarning, maxPriorityFeePerGasError, maxPriorityFeePerGasWarning, legacyGasPriceError, legacyGasPriceWarning, gasLimitError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$hooks$2f$useNetworkFeeGasValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        maxFeePerGas: values.maxFeePerGas,
        maxPriorityFeePerGas: values.maxPriorityFeePerGas,
        gasPrice: values.gasPrice,
        gasLimit: values.gasLimit,
        estimatedGas
    });
    const getGasPriceGwei = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "NetworkFeeDialogContent.useCallback[getGasPriceGwei]": (_gasOption)=>{
            if (_gasOption === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM && (baseFee || gasPrice)) {
                if (values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY) {
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.gasPrice);
                }
                if (values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559) {
                    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$parseGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseGwei"])(values.maxFeePerGas);
                }
            }
            if (_gasOption !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM && (baseFee || gasPrice)) {
                if (values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 && baseFee) {
                    return baseFee * __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][_gasOption] / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"];
                }
                if (gasPrice) {
                    return gasPrice * __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["baseFeeMultipliers"][chainId][_gasOption] / __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$baseFeeMultipliers$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SCALING_FACTOR"];
                }
            }
            return BigInt(0);
        }
    }["NetworkFeeDialogContent.useCallback[getGasPriceGwei]"], [
        baseFee,
        chainId,
        gasPrice,
        values.gasPrice,
        values.gasPriceModel,
        values.maxFeePerGas
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
        className: "max-md:h-[calc(100%-60px)]",
        onSubmit: handleSubmit,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "max-md:h-[calc(100%-80px)] overflow-auto flex flex-col gap-2 card-spacing-x",
                children: gasOptions.map((_gasOption)=>{
                    const gasPriceETH = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatEther$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatEther"])(getGasPriceGwei(_gasOption) * estimatedGas));
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$GasOptionRadioButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        gasPriceGWEI: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$formatFloat$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatFloat"])((0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$unit$2f$formatGwei$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatGwei"])(getGasPriceGwei(_gasOption)))} GWEI`,
                        gasPriceCurrency: `${gasPriceETH} ${nativeCurrency.symbol}`,
                        tooltipText: tooltipTextMap[_gasOption],
                        title: gasOptionTitle[_gasOption],
                        iconName: gasOptionIcon[_gasOption],
                        customContent: _gasOption === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(values.gasPriceOption !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM && "opacity-30 pointer-events-none"),
                            children: [
                                !isAdvanced && (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEip1559Supported"])(chainId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("px-5 pb-4"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ConfigureAutomatically$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            gasPriceModel: values.gasPriceModel,
                                            setFieldValue: setFieldValue
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 320,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$EIP1559Fields$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            maxPriorityFeePerGas: values.maxPriorityFeePerGas,
                                            maxFeePerGas: values.maxFeePerGas,
                                            setMaxFeePerGasValue: (value)=>setFieldValue("maxFeePerGas", value),
                                            setMaxPriorityFeePerGasValue: (value)=>setFieldValue("maxPriorityFeePerGas", value),
                                            currentMaxFeePerGas: baseFee,
                                            currentMaxPriorityFeePerGas: priorityFee,
                                            handleChange: handleChange,
                                            handleBlur: handleBlur,
                                            maxFeePerGasError: maxFeePerGasError,
                                            maxFeePerGasWarning: maxFeePerGasWarning,
                                            maxPriorityFeePerGasError: maxPriorityFeePerGasError,
                                            maxPriorityFeePerGasWarning: maxPriorityFeePerGasWarning
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 324,
                                            columnNumber: 25
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                    lineNumber: 319,
                                    columnNumber: 23
                                }, void 0),
                                !isAdvanced && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEip1559Supported"])(chainId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("px-5 pb-4"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ConfigureAutomatically$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            gasPriceModel: values.gasPriceModel,
                                            setFieldValue: setFieldValue
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 345,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$LegacyField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            value: values.gasPrice,
                                            onChange: (e)=>{
                                                handleChange(e);
                                            },
                                            onBlur: (e)=>{
                                                handleBlur(e);
                                            },
                                            gasPrice: gasPrice,
                                            setFieldValue: (value)=>setFieldValue("gasPrice", value),
                                            legacyGasPriceError: legacyGasPriceError,
                                            legacyGasPriceWarning: legacyGasPriceWarning
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 349,
                                            columnNumber: 25
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                    lineNumber: 344,
                                    columnNumber: 23
                                }, void 0),
                                isAdvanced && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEip1559Supported"])(chainId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("px-5 pb-4 flex flex-col gap-4"),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ConfigureAutomatically$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            gasPriceModel: values.gasPriceModel,
                                            setFieldValue: setFieldValue
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 367,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$LegacyField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            value: values.gasPrice,
                                            onChange: (e)=>{
                                                handleChange(e);
                                            },
                                            onBlur: (e)=>{
                                                handleBlur(e);
                                            },
                                            gasPrice: gasPrice,
                                            setFieldValue: (value)=>setFieldValue("gasPrice", value),
                                            legacyGasPriceError: legacyGasPriceError,
                                            legacyGasPriceWarning: legacyGasPriceWarning
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 371,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$GasLimitField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            onChange: (e)=>setFieldValue("gasLimit", e.target.value),
                                            onBlur: (e)=>handleBlur(e),
                                            setFieldValue: (value)=>setFieldValue("gasLimit", value),
                                            value: values.gasLimit,
                                            estimatedGas: estimatedGas,
                                            gasLimitError: gasLimitError
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 385,
                                            columnNumber: 25
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                    lineNumber: 366,
                                    columnNumber: 23
                                }, void 0),
                                isAdvanced && (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$eip1559$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isEip1559Supported"])(chainId) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "px-5 pb-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$ConfigureAutomatically$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            gasPriceModel: values.gasPriceModel,
                                            setFieldValue: setFieldValue
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 398,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "pb-5",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "grid grid-cols-2 gap-1 p-1 rounded-3 bg-secondary-bg mb-4",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 ? "bg-green-bg border-green" : "bg-primary-bg border-transparent", "flex flex-col gap-1 justify-center group/button items-center py-3 px-5 border group  rounded-3 duration-200", "hover:bg-green-bg"),
                                                            onClick: ()=>setFieldValue("gasPriceModel", __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559),
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex items-center gap-1", values.gasPriceModel !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 && "text-secondary-text"),
                                                                    children: [
                                                                        "EIP-1559",
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            text: "There are two types of transactions: EIP-1559 and legacy. The type of transaction affects the formula for gas payments calculation. EIP-1559 transactions are recommended for networks and wallets that have it supported."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                            lineNumber: 423,
                                                                            columnNumber: 33
                                                                        }, void 0)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                    lineNumber: 415,
                                                                    columnNumber: 31
                                                                }, void 0),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-12 duration-200", values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 ? "text-secondary-text " : "text-tertiary-text group-hover/button:text-secondary-text"),
                                                                    children: "Network Fee = gasLimit × (Base Fee + PriorityFee)"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                    lineNumber: 425,
                                                                    columnNumber: 31
                                                                }, void 0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                            lineNumber: 404,
                                                            columnNumber: 29
                                                        }, void 0),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                            type: "button",
                                                            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY ? "bg-green-bg border-green" : "bg-primary-bg border-transparent", "flex flex-col gap-1 justify-center group/button items-center py-3 px-5 border group  rounded-3 duration-200", "hover:bg-green-bg"),
                                                            onClick: ()=>setFieldValue("gasPriceModel", __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY),
                                                            children: [
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex items-center gap-1", values.gasPriceModel !== __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY && "text-secondary-text"),
                                                                    children: [
                                                                        "Legacy",
                                                                        " ",
                                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                            text: "There are two types of transactions: EIP-1559 and legacy. The type of transaction affects the formula for gas payments calculation. Legacy transactions allow you to determine the exact gasPrice you are going to pay. EIP-1559 transactions are recommended for networks that support it."
                                                                        }, void 0, false, {
                                                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                            lineNumber: 455,
                                                                            columnNumber: 33
                                                                        }, void 0)
                                                                    ]
                                                                }, void 0, true, {
                                                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                    lineNumber: 447,
                                                                    columnNumber: 31
                                                                }, void 0),
                                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                    className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("text-12 duration-200", values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY ? "text-secondary-text " : "text-tertiary-text group-hover/button:text-secondary-text"),
                                                                    children: "Network Fee = gasLimit × gasPrice"
                                                                }, void 0, false, {
                                                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                    lineNumber: 457,
                                                                    columnNumber: 31
                                                                }, void 0)
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                            lineNumber: 436,
                                                            columnNumber: 29
                                                        }, void 0)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                    lineNumber: 403,
                                                    columnNumber: 27
                                                }, void 0),
                                                values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$EIP1559Fields$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                            maxPriorityFeePerGas: values.maxPriorityFeePerGas,
                                                            maxFeePerGas: values.maxFeePerGas,
                                                            setMaxFeePerGasValue: (value)=>setFieldValue("maxFeePerGas", value),
                                                            setMaxPriorityFeePerGasValue: (value)=>setFieldValue("maxPriorityFeePerGas", value),
                                                            currentMaxFeePerGas: baseFee,
                                                            currentMaxPriorityFeePerGas: priorityFee,
                                                            handleChange: handleChange,
                                                            handleBlur: handleBlur,
                                                            maxFeePerGasError: maxFeePerGasError,
                                                            maxFeePerGasWarning: maxFeePerGasWarning,
                                                            maxPriorityFeePerGasError: maxPriorityFeePerGasError,
                                                            maxPriorityFeePerGasWarning: maxPriorityFeePerGasWarning
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                            lineNumber: 471,
                                                            columnNumber: 31
                                                        }, void 0),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                            className: "mt-5",
                                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Alert$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                                text: "Сhanging Priority Fee only in order to make transaction cheaper or speed it up at a cost of paying higher fee.",
                                                                type: "info-border"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                                lineNumber: 490,
                                                                columnNumber: 33
                                                            }, void 0)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                            lineNumber: 489,
                                                            columnNumber: 31
                                                        }, void 0)
                                                    ]
                                                }, void 0, true),
                                                values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "mt-4",
                                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$LegacyField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                        value: values.gasPrice,
                                                        onChange: (e)=>{
                                                            handleChange(e);
                                                        },
                                                        onBlur: (e)=>{
                                                            handleBlur(e);
                                                        },
                                                        gasPrice: gasPrice,
                                                        setFieldValue: (value)=>setFieldValue("gasPrice", value),
                                                        legacyGasPriceError: legacyGasPriceError,
                                                        legacyGasPriceWarning: legacyGasPriceWarning
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                        lineNumber: 499,
                                                        columnNumber: 31
                                                    }, void 0)
                                                }, void 0, false, {
                                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                                    lineNumber: 498,
                                                    columnNumber: 29
                                                }, void 0)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 402,
                                            columnNumber: 25
                                        }, void 0),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$GasLimitField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            onChange: (e)=>setFieldValue("gasLimit", e.target.value),
                                            onBlur: (e)=>handleBlur(e),
                                            setFieldValue: (value)=>setFieldValue("gasLimit", value),
                                            value: values.gasLimit,
                                            estimatedGas: estimatedGas,
                                            gasLimitError: gasLimitError
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                            lineNumber: 515,
                                            columnNumber: 25
                                        }, void 0)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                    lineNumber: 397,
                                    columnNumber: 23
                                }, void 0)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                            lineNumber: 312,
                            columnNumber: 19
                        }, void 0) : undefined,
                        isActive: values.gasPriceOption === _gasOption,
                        onClick: ()=>setFieldValue("gasPriceOption", _gasOption)
                    }, _gasOption, false, {
                        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                        lineNumber: 303,
                        columnNumber: 13
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                lineNumber: 298,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "px-4 mb-4 md:px-10 md:mb-10 pt-4 grid grid-cols-2 gap-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        type: "button",
                        fullWidth: true,
                        onClick: handleCancel,
                        colorScheme: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ButtonColor"].LIGHT_GREEN,
                        children: "Cancel"
                    }, void 0, false, {
                        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                        lineNumber: 536,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        disabled: Boolean(!isAdvanced && (maxFeePerGasError || maxPriorityFeePerGasError) && values.gasPriceOption === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM && values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].EIP1559 || gasLimitError || !isAdvanced && values.gasPriceOption === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasOption"].CUSTOM && values.gasPriceModel === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$factories$2f$createGasPriceStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["GasFeeModel"].LEGACY && legacyGasPriceError),
                        type: "submit",
                        fullWidth: true,
                        children: "Apply"
                    }, void 0, false, {
                        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                        lineNumber: 544,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                lineNumber: 535,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
        lineNumber: 297,
        columnNumber: 5
    }, this);
}
_s(NetworkFeeDialogContent, "WvaPSwtNme7aLAn9aqtklzowo/o=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useGlobalFees$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useGlobalFees"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDeepEffect$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useNativeCurrency$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useNativeCurrency"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$formik$2f$dist$2f$formik$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useFormik"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$gas$2d$settings$2f$hooks$2f$useNetworkFeeGasValidation$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c = NetworkFeeDialogContent;
function NetworkFeeConfigDialog({ isOpen, setIsOpen, isAdvanced, setIsAdvanced, ...props }) {
    _s1();
    const [containerHeight, setContainerHeight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("auto"); // Default to auto height
    const ref = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Function to check and adjust the container height based on the content
    // Run adjustHeight on window resize or on initial load
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NetworkFeeConfigDialog.useEffect": ()=>{
            if (!ref.current) return;
            const adjustHeight = {
                "NetworkFeeConfigDialog.useEffect.adjustHeight": ()=>{
                    const contentHeight = ref.current?.scrollHeight; // Get the height of the content
                    if (!contentHeight) {
                        return;
                    }
                    const viewportHeight = window.innerHeight;
                    // Set container height to 100vh only if content exceeds the viewport height
                    if (contentHeight > viewportHeight && window.innerWidth < 768) {
                        setContainerHeight("100dvh");
                    } else {
                        setContainerHeight("auto");
                    }
                }
            }["NetworkFeeConfigDialog.useEffect.adjustHeight"];
            adjustHeight();
            const debouncedAdjustHeight = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$lodash$2e$debounce$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(adjustHeight, 300);
            window.addEventListener("resize", debouncedAdjustHeight);
            // Cleanup function to remove the listener and cancel debounce
            return ({
                "NetworkFeeConfigDialog.useEffect": ()=>{
                    window.removeEventListener("resize", debouncedAdjustHeight);
                    debouncedAdjustHeight.cancel(); // Cancel any pending invocations of the debounced function
                }
            })["NetworkFeeConfigDialog.useEffect"];
        }
    }["NetworkFeeConfigDialog.useEffect"], [
        isAdvanced
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DrawerDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        isOpen: isOpen,
        setIsOpen: setIsOpen,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            ref: ref,
            className: "w-full md:w-[800px] duration-200 overflow-hidden",
            style: {
                height: containerHeight
            },
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DialogHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    onClose: ()=>setIsOpen(false),
                    title: "Gas settings",
                    settings: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-12",
                                children: "Advanced mode"
                            }, void 0, false, {
                                fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                lineNumber: 620,
                                columnNumber: 15
                            }, void 0),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Switch$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                checked: isAdvanced,
                                handleChange: ()=>setIsAdvanced(!isAdvanced)
                            }, void 0, false, {
                                fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                                lineNumber: 621,
                                columnNumber: 15
                            }, void 0)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                        lineNumber: 619,
                        columnNumber: 13
                    }, void 0)
                }, void 0, false, {
                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                    lineNumber: 615,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(NetworkFeeDialogContent, {
                    ...props,
                    setIsOpen: setIsOpen,
                    isAdvanced: isAdvanced
                }, void 0, false, {
                    fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
                    lineNumber: 625,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
            lineNumber: 610,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx",
        lineNumber: 609,
        columnNumber: 5
    }, this);
} //1170 => 1133 => 797 => 826 => 861 => 714 => 681 => 607
_s1(NetworkFeeConfigDialog, "o+PJSWj1K0QOk2BMuqnBUH9jNMg=");
_c1 = NetworkFeeConfigDialog;
var _c, _c1;
__turbopack_context__.k.register(_c, "NetworkFeeDialogContent");
__turbopack_context__.k.register(_c1, "NetworkFeeConfigDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/config/tokens/index.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "loadChainTokens",
    ()=>loadChainTokens
]);
const loadChainTokens = async (chainId)=>{
    if (!chainId) return Promise.resolve([]);
    try {
        const chainTokens = (await __turbopack_context__.f({
            "./1_predicted.json": {
                id: ()=>"[project]/app/config/tokens/1_predicted.json (json, async loader)",
                module: ()=>__turbopack_context__.A("[project]/app/config/tokens/1_predicted.json (json, async loader)")
            }
        }).import(`./${chainId}_predicted.json`)).default;
        if (chainTokens?.length) {
            return chainTokens;
        } else {
            return Promise.resolve([]);
        }
    } catch (error) {
        return Promise.resolve([]);
    }
};
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/ScrollbarContainer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ScrollbarContainer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$simplebar$2d$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/simplebar-react/dist/index.mjs [app-client] (ecmascript)");
;
;
;
function ScrollbarContainer({ children, height, scrollableNodeProps, style = {}, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$simplebar$2d$react$2f$dist$2f$index$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        scrollableNodeProps: scrollableNodeProps,
        className: props.className,
        autoHide: false,
        style: height === "full" ? {
            flex: 1,
            display: "flex",
            flexDirection: "column",
            ...style
        } : {
            height: `${height}px`,
            ...style
        },
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/app/components/atoms/ScrollbarContainer.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_c = ScrollbarContainer;
var _c;
__turbopack_context__.k.register(_c, "ScrollbarContainer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/organisms/PickTokenDialog.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>PickTokenDialog,
    "filterTokens",
    ()=>filterTokens
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-virtual/dist/esm/index.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DialogHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/DialogHeader.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DrawerDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/DrawerDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/SelectButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$tokens$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/tokens/index.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertTokenStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$IIFE$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/IIFE.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$ScrollbarContainer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/ScrollbarContainer.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const generateOrderedSubsets = (arr)=>{
    const _arr = [];
    for(let start = 1; start < arr.length; start++){
        let subset = "";
        for(let end = start; end < arr.length; end++){
            subset = subset ? `${subset} ${arr[end]}` : arr[end];
            _arr.push(subset);
        }
    }
    return _arr;
};
function filterTokens(searchStr, tokens) {
    return tokens.filter((token)=>{
        // const nameParts = token.name ? token.name.split(" ") : [];
        const symbolParts = token.symbol ? token.symbol.split(" ") : [];
        const addressParts = [
            token.address0,
            token.address1
        ];
        const allPartsArr = [
            ...symbolParts,
            ...addressParts
        ];
        // if (token.name && nameParts.length > 1) {
        //   allPartsArr.push(token.name);
        // }
        if (token.symbol && symbolParts.length > 1) {
            allPartsArr.push(token.symbol);
        }
        const allParts = Array.from(new Set([
            ...allPartsArr,
            // ...generateOrderedSubsets(nameParts),
            ...generateOrderedSubsets(symbolParts)
        ]));
        for(let i = 0; i < allParts.length; i++){
            if (allParts[i].toLowerCase().startsWith(searchStr.toLowerCase())) {
                return true;
            }
        }
    });
}
function TokenRowSimple({ currency, handlePick, isMobile, prevToken }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        role: "button",
        onClick: ()=>handlePick(currency),
        className: "rounded-2 flex items-center flex-wrap md:block md:rounded-0 pl-3 pr-1.5 md:pl-10 md:pr-7 bg-transparent hover:bg-tertiary-bg duration-200 group py-1 md:py-2 w-full text-left",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid md:grid-cols-[40px_1fr] grid-cols-[32px_1fr] gap-2 w-full",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                        src: currency?.logoURI !== "/tokens/placeholder.svg" ? currency?.logoURI || "" : "/images/tokens/placeholder.svg",
                        alt: "",
                        className: "w-8 h-8"
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                        lineNumber: 82,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                    lineNumber: 81,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "w-full pl-1 md:pl-0",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between w-full",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center md:gap-x-2 flex-wrap",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-center w-[120px] md:gap-2 md:w-[256px]",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "whitespace-nowrap overflow-ellipsis overflow-hidden",
                                            children: currency.symbol
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                            lineNumber: 96,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                        lineNumber: 95,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "w-full ",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "w-[300px] whitespace-nowrap overflow-hidden overflow-ellipsis block text-secondary-text text-12  md:text-14",
                                            children: currency.name
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                            lineNumber: 102,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                        lineNumber: 101,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "block w-10"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                        lineNumber: 109,
                                        columnNumber: 15
                                    }, this),
                                    prevToken && prevToken.symbol === currency.symbol && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        iconName: "check",
                                        className: "text-green mr-1.5"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                        lineNumber: 111,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                lineNumber: 108,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                        lineNumber: 93,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
            lineNumber: 80,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
        lineNumber: 75,
        columnNumber: 5
    }, this);
}
_c = TokenRowSimple;
function PickTokenDialog({ onPick }) {
    _s();
    const [tokens, setTokens] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const parentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { token, setToken, setTokenStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "PickTokenDialog.useEffect": ()=>{
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$IIFE$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IIFE"])({
                "PickTokenDialog.useEffect": async ()=>{
                    const tokens = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$tokens$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["loadChainTokens"])(chainId);
                    const formatted = tokens?.map({
                        "PickTokenDialog.useEffect": ({ addressERC20, addressERC223, name, decimals, symbol, logo, isErc223 })=>({
                                address0: addressERC20,
                                address1: addressERC223,
                                symbol,
                                name,
                                decimals,
                                logoURI: logo,
                                chainId,
                                isErc223Origin: isErc223
                            })
                    }["PickTokenDialog.useEffect"]);
                    setTokens(formatted || []);
                }
            }["PickTokenDialog.useEffect"]);
        }
    }["PickTokenDialog.useEffect"], [
        chainId
    ]);
    const virtualizer = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"])({
        count: tokens.length,
        getScrollElement: {
            "PickTokenDialog.useVirtualizer[virtualizer]": ()=>parentRef.current
        }["PickTokenDialog.useVirtualizer[virtualizer]"],
        estimateSize: {
            "PickTokenDialog.useVirtualizer[virtualizer]": ()=>60
        }["PickTokenDialog.useVirtualizer[virtualizer]"]
    });
    const items = virtualizer.getVirtualItems();
    const minYPadding = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PickTokenDialog.useMemo[minYPadding]": ()=>tokens?.length ? 8 : 0
    }["PickTokenDialog.useMemo[minYPadding]"], [
        tokens
    ]);
    const [tokensSearchValue, setTokensSearchValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [paddingTop, paddingBottom] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PickTokenDialog.useMemo": ()=>{
            return items.length > 0 ? [
                Math.max(minYPadding, items[0].start),
                Math.max(8, virtualizer.getTotalSize() - items[items.length - 1].end)
            ] : [
                minYPadding,
                8
            ];
        }
    }["PickTokenDialog.useMemo"], [
        items,
        minYPadding,
        virtualizer
    ]);
    const [filteredTokens, isTokenFilterActive] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "PickTokenDialog.useMemo": ()=>{
            return tokensSearchValue ? [
                filterTokens(tokensSearchValue, tokens),
                true
            ] : [
                tokens,
                false
            ];
        }
    }["PickTokenDialog.useMemo"], [
        tokens,
        tokensSearchValue
    ]);
    //
    // const { token: derivedToken, isLoading } = useDerivedTokenInfo({
    //   tokenAddressToImport: tokensSearchValue as Address,
    //   enabled: !!tokensSearchValue && isAddress(tokensSearchValue) && filteredTokens.length === 0,
    // });
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$SelectButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                fullWidth: true,
                className: "bg-quaternary-bg h-12 pl-5",
                onClick: ()=>setIsOpen(true),
                children: token ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                            className: "w-6 h-6 rounded-full",
                            src: token.logoURI,
                            alt: ""
                        }, void 0, false, {
                            fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                            lineNumber: 187,
                            columnNumber: 13
                        }, this),
                        token.symbol
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                    lineNumber: 186,
                    columnNumber: 11
                }, this) : "Select token"
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                lineNumber: 180,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DrawerDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: isOpen,
                setIsOpen: setIsOpen,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$DialogHeader$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        onClose: ()=>setIsOpen(false),
                        title: "Select token"
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                        lineNumber: 195,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "w-full sm:w-[600px] max-h-[580px] h-[calc(100vh_-_60px)] flex flex-col",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("card-spacing-x pb-3"),
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["SearchInput"], {
                                    value: tokensSearchValue,
                                    onChange: (e)=>setTokensSearchValue(e.target.value),
                                    placeholder: "Search name or token contract"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                    lineNumber: 198,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                lineNumber: 197,
                                columnNumber: 11
                            }, this),
                            Boolean(filteredTokens.length) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-grow flex min-h-0 overflow-hidden",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$ScrollbarContainer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    scrollableNodeProps: {
                                        ref: parentRef
                                    },
                                    height: "full",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("flex flex-col gap-2 md:gap-0 md:pl-0 md:pr-[11px] pt-3 pl-2 pr-3"),
                                        style: {
                                            paddingTop,
                                            paddingBottom
                                        },
                                        children: items.map((item)=>{
                                            const token = filteredTokens[item.index];
                                            // if (simpleForm)
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(TokenRowSimple, {
                                                handlePick: (token)=>{
                                                    onPick();
                                                    setToken(token);
                                                    if (token.isErc223Origin) {
                                                        setTokenStandard(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223);
                                                    }
                                                    setIsOpen(false);
                                                },
                                                currency: token,
                                                isMobile: false
                                            }, token.address0, false, {
                                                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                                lineNumber: 225,
                                                columnNumber: 23
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                        lineNumber: 212,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                    lineNumber: 206,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                                lineNumber: 205,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                        lineNumber: 196,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/PickTokenDialog.tsx",
                lineNumber: 194,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(PickTokenDialog, "cxQJBHFTyvz6YMDXIP4d+6TTE6c=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$virtual$2f$dist$2f$esm$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["useVirtualizer"]
    ];
});
_c1 = PickTokenDialog;
var _c, _c1;
__turbopack_context__.k.register(_c, "TokenRowSimple");
__turbopack_context__.k.register(_c1, "PickTokenDialog");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/hooks/useDerivedTokenInfo.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>useDerivedTokenInfo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ethereumjs$2f$util$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@ethereumjs/util/dist/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/address/isAddress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/wagmi/dist/esm/hooks/useReadContract.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/abis/erc20.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc223$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/abis/erc223.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/abis/tokenConverter.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/addresses.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
;
;
;
;
;
;
;
;
;
function useDerivedTokenInfo({ tokenAddressToImport, enabled }) {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { data: tokenName, isFetched, isLoading: isLoadingName } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC20_ABI"],
        functionName: "name",
        chainId,
        address: tokenAddressToImport,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport)
        }
    });
    const { data: tokenSymbol, isLoading: isLoadingSymbol } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC20_ABI"],
        functionName: "symbol",
        address: tokenAddressToImport,
        chainId,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport)
        }
    });
    const { data: tokenDecimals, isLoading: isLoadingDecimals } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc20$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC20_ABI"],
        functionName: "decimals",
        address: tokenAddressToImport,
        chainId,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport)
        }
    });
    const { data: standard, isLoading: isLoadingStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$erc223$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ERC223_ABI"],
        functionName: "standard",
        address: tokenAddressToImport,
        chainId,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport)
        }
    });
    const { data: isWrapper, isLoading: isLoadingWrapper } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOKEN_CONVERTER_ABI"],
        functionName: "isWrapper",
        address: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
        args: [
            tokenAddressToImport
        ],
        chainId,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport)
        }
    });
    const otherAddressFunctionName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDerivedTokenInfo.useMemo[otherAddressFunctionName]": ()=>{
            if (isWrapper == null) {
                return null;
            }
            if (isWrapper) {
                if (standard === 223) {
                    return "getERC20OriginFor";
                }
                return "getERC223OriginFor";
            }
            return "predictWrapperAddress";
        }
    }["useDerivedTokenInfo.useMemo[otherAddressFunctionName]"], [
        isWrapper,
        standard
    ]);
    const otherAddressCheckFunctionName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDerivedTokenInfo.useMemo[otherAddressCheckFunctionName]": ()=>{
            if (otherAddressFunctionName !== "predictWrapperAddress") {
                return null;
            }
            if (standard === 223) {
                return "getERC20WrapperFor";
            }
            return "getERC223WrapperFor";
        }
    }["useDerivedTokenInfo.useMemo[otherAddressCheckFunctionName]"], [
        otherAddressFunctionName,
        standard
    ]);
    const { data: otherAddress, isLoading: isLoadingOtherAddress } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOKEN_CONVERTER_ABI"],
        functionName: otherAddressCheckFunctionName,
        address: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
        args: [
            tokenAddressToImport
        ],
        chainId,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport) && Boolean(otherAddressCheckFunctionName)
        }
    });
    console.log(otherAddress);
    const { data: predictedOtherAddress, isLoading: isLoadingOtherAddressFunction } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"])({
        abi: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$abis$2f$tokenConverter$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["TOKEN_CONVERTER_ABI"],
        functionName: otherAddressFunctionName,
        address: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$addresses$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["CONVERTER_ADDRESS"][chainId],
        args: [
            tokenAddressToImport,
            standard !== 223
        ],
        chainId,
        query: {
            enabled: !!tokenAddressToImport && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(tokenAddressToImport) && Boolean(otherAddressFunctionName)
        }
    });
    console.log(predictedOtherAddress);
    const { erc20AddressToImport, erc223AddressToImport, isErc20Exist, isErc223Exist } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDerivedTokenInfo.useMemo": ()=>{
            if (standard && +standard === 223) {
                return {
                    erc20AddressToImport: predictedOtherAddress,
                    erc223AddressToImport: tokenAddressToImport,
                    isErc20Exist: otherAddress && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(otherAddress) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ethereumjs$2f$util$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isZeroAddress"])(otherAddress),
                    isErc223Exist: true
                };
            }
            return {
                erc20AddressToImport: tokenAddressToImport,
                erc223AddressToImport: predictedOtherAddress,
                isErc223Exist: otherAddress && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(otherAddress) && !(0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$ethereumjs$2f$util$2f$dist$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isZeroAddress"])(otherAddress),
                isErc20Exist: true
            };
        }
    }["useDerivedTokenInfo.useMemo"], [
        otherAddress,
        predictedOtherAddress,
        standard,
        tokenAddressToImport
    ]);
    const isTokenLoading = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDerivedTokenInfo.useMemo[isTokenLoading]": ()=>{
            console.log("isLoadingSymbol", isLoadingSymbol);
            console.log("isLoadingDecimals", isLoadingDecimals);
            console.log("isLoadingStandard", isLoadingStandard);
            console.log("isLoadingName", isLoadingName);
            console.log("isLoadingOtherAddressFunction", isLoadingOtherAddressFunction);
            if (!enabled) {
                return false;
            }
            return isLoadingStandard || isLoadingDecimals || isLoadingName || isLoadingOtherAddressFunction || isLoadingOtherAddress || isLoadingSymbol || isLoadingWrapper;
        }
    }["useDerivedTokenInfo.useMemo[isTokenLoading]"], [
        enabled,
        isLoadingDecimals,
        isLoadingName,
        isLoadingOtherAddress,
        isLoadingOtherAddressFunction,
        isLoadingStandard,
        isLoadingSymbol,
        isLoadingWrapper
    ]);
    const token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useDerivedTokenInfo.useMemo[token]": ()=>{
            if (!tokenSymbol || !tokenName || !tokenDecimals || !enabled || !erc20AddressToImport || !erc223AddressToImport || isTokenLoading) {
                console.log("Not enought data");
                return undefined;
            }
            return {
                chainId: chainId,
                address0: erc20AddressToImport,
                address1: erc223AddressToImport,
                decimals: tokenDecimals,
                symbol: tokenSymbol,
                name: tokenName,
                isErc223Origin: !!(standard && +standard === 223),
                logoURI: "/images/tokens/placeholder.svg"
            };
        }
    }["useDerivedTokenInfo.useMemo[token]"], [
        chainId,
        enabled,
        erc20AddressToImport,
        erc223AddressToImport,
        isTokenLoading,
        standard,
        tokenDecimals,
        tokenName,
        tokenSymbol
    ]);
    return {
        token,
        isLoading: isTokenLoading
    };
}
_s(useDerivedTokenInfo, "IHLSJ216sh2X4zNcJToX3av68TA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$wagmi$2f$dist$2f$esm$2f$hooks$2f$useReadContract$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useReadContract"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/organisms/Converter.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Converter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/viem/_esm/utils/address/isAddress.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/TextField.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$dialogs$2f$NetworkFeeConfigDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/dialogs/NetworkFeeConfigDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$PickTokenDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/organisms/PickTokenDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useCurrentChainId.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDerivedTokenInfo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/hooks/useDerivedTokenInfo.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConfirmConvertDialogOpened$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConfirmConvertDialogOpened.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertAmountStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertGasSettingsStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertTokenStore.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function StandardCard({ symbol, standard }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "pl-5 pr-4 py-2.5 rounded-3 bg-quaternary-bg flex justify-between items-center",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex text-secondary-text text-18 gap-1 items-center",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: standard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? "text-purple font-medium" : "text-green font-semibold",
                        children: standard
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 27,
                        columnNumber: 9
                    }, this),
                    " ",
                    symbol
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                text: "Text"
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/organisms/Converter.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_c = StandardCard;
function StandardText({ standard }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: standard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? "text-purple " : "text-green font-semibold",
        children: standard
    }, void 0, false, {
        fileName: "[project]/app/components/organisms/Converter.tsx",
        lineNumber: 43,
        columnNumber: 5
    }, this);
}
_c1 = StandardText;
function Converter() {
    _s();
    const chainId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])();
    const { setIsOpen: setConfirmConvertDialogOpen } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConfirmConvertDialogOpened$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfirmConvertDialogStore"])();
    const { typedValue, setTypedValue, reset: resetAmounts } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"])();
    const { token, tokenStandard, setTokenStandard, setToken, switchStandard } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])();
    const [isOpenedFeeSettings, setIsOpenedFeeSettings] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { gasPriceSettings, gasPriceOption, setGasPriceOption, setGasPriceSettings, updateDefaultState } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasPriceStore"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Converter.useEffect": ()=>{
            updateDefaultState(chainId);
        }
    }["Converter.useEffect"], [
        chainId,
        updateDefaultState
    ]);
    const { customGasLimit, estimatedGas, setCustomGasLimit, setEstimatedGas } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"])();
    const { isAdvanced, setIsAdvanced } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasModeStore"])();
    const [addressToSearch, setAddressToSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const { isLoading, token: derivedToken } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDerivedTokenInfo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])({
        tokenAddressToImport: addressToSearch,
        enabled: !!addressToSearch && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(addressToSearch)
    });
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Converter.useEffect": ()=>{
            if (addressToSearch && (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$viem$2f$_esm$2f$utils$2f$address$2f$isAddress$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["isAddress"])(addressToSearch) && derivedToken) {
                setToken({
                    ...derivedToken
                });
                if (derivedToken.isErc223Origin) {
                    setTokenStandard(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223);
                } else {
                    setTokenStandard(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20);
                }
            }
        }
    }["Converter.useEffect"], [
        addressToSearch,
        derivedToken,
        setToken,
        setTokenStandard
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "max-w-[680px] mx-auto",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                className: "flex items-center gap-1 text-40 font-medium mb-2 mt-10",
                children: [
                    "ERC-20 ",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        iconName: "swap"
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 93,
                        columnNumber: 16
                    }, this),
                    " ERC-223 token converter"
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-secondary-text text-center",
                children: [
                    "This is a token converter that converts ERC-20 tokens to ERC-223. It can also convert ERC-223 tokens back to ERC-20 at any time. No fees are charged.",
                    " "
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 95,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-secondary-text text-center mb-8",
                children: "Read more about the conversion process"
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 99,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "card-spacing-x card-spacing-y rounded-5 bg-primary-bg flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-tertiary-bg px-5 py-3 rounded-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-20 font-medium mb-1",
                                children: "Select token to convert"
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 103,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$PickTokenDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                onPick: ()=>{
                                    setAddressToSearch("");
                                }
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 104,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative mt-1 flex justify-center before:absolute before:left-0 before:h-px before:w-full before:top-1/2 before:-translate-y-1/2 before:bg-secondary-border",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "block bg-tertiary-bg px-2 relative z-10 text-tertiary-text",
                                    children: "OR"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/Converter.tsx",
                                    lineNumber: 110,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 109,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                value: addressToSearch,
                                onChange: (e)=>{
                                    setAddressToSearch(e.target.value);
                                },
                                label: "",
                                placeholder: "Enter token contract address"
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 112,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 102,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-tertiary-bg grid grid-cols-[1fr_48px_1fr] rounded-3 px-5 pb-5 pt-3 gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mb-1 text-20 font-medium",
                                        children: "You send"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 123,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StandardCard, {
                                        symbol: token?.symbol,
                                        standard: tokenStandard
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 124,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 122,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-end",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: switchStandard,
                                    className: "bg-secondary-bg w-12 h-12 flex items-center justify-center rounded-3 text-green hover:text-[#A5E7E6] cursor-pointer duration-200",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        iconName: "swap"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 131,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/Converter.tsx",
                                    lineNumber: 127,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 126,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mb-1 text-20 font-medium",
                                        children: "You receive"
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 135,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StandardCard, {
                                        symbol: token?.symbol,
                                        standard: tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223 : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 136,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 134,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 121,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-tertiary-bg rounded-3 px-5 py-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-20 font-medium",
                                children: "Enter amount"
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TextField$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                value: typedValue,
                                onChange: (e)=>{
                                    setTypedValue({
                                        typedValue: e.target.value
                                    });
                                },
                                internalText: "USDT",
                                label: "",
                                placeholder: "0"
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 145,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-tertiary-bg rounded-3 border border-blue px-5 py-3 flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                className: "text-blue",
                                iconName: "convert"
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 157,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                children: [
                                    "You are converting your ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StandardText, {
                                        standard: tokenStandard
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 159,
                                        columnNumber: 37
                                    }, this),
                                    " tokens to",
                                    " ",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(StandardText, {
                                        standard: tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223 : __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/Converter.tsx",
                                        lineNumber: 160,
                                        columnNumber: 13
                                    }, this),
                                    " ",
                                    "tokens"
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/Converter.tsx",
                                lineNumber: 158,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 156,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "bg-tertiary-bg rounded-3 overflow-hidden",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                            onClick: ()=>setIsOpenedFeeSettings(!isOpenedFeeSettings),
                            className: "w-full h-12 flex items-center justify-between px-5 hover:bg-green-bg cursor-pointer duration-200",
                            children: [
                                "Network fee ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    iconName: "small-expand-arrow"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/organisms/Converter.tsx",
                                    lineNumber: 172,
                                    columnNumber: 25
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/organisms/Converter.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        fullWidth: true,
                        onClick: ()=>setConfirmConvertDialogOpen(true),
                        children: [
                            "Convert ",
                            token?.symbol,
                            " to ",
                            tokenStandard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223 ? "ERC-20" : "ERC-223"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/Converter.tsx",
                        lineNumber: 176,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$dialogs$2f$NetworkFeeConfigDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isAdvanced: isAdvanced,
                setIsAdvanced: setIsAdvanced,
                estimatedGas: estimatedGas,
                setEstimatedGas: setEstimatedGas,
                gasPriceSettings: gasPriceSettings,
                gasPriceOption: gasPriceOption,
                customGasLimit: customGasLimit,
                setCustomGasLimit: setCustomGasLimit,
                setGasPriceOption: setGasPriceOption,
                setGasPriceSettings: setGasPriceSettings,
                isOpen: isOpenedFeeSettings,
                setIsOpen: setIsOpenedFeeSettings
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/Converter.tsx",
                lineNumber: 181,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/organisms/Converter.tsx",
        lineNumber: 91,
        columnNumber: 5
    }, this);
}
_s(Converter, "K94KSvgX0OG+mFJyWA8MZIGqNYY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useCurrentChainId$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConfirmConvertDialogOpened$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConfirmConvertDialogStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertAmountStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertAmountStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasPriceStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasLimitStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertGasSettingsStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertGasModeStore"],
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$hooks$2f$useDerivedTokenInfo$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"]
    ];
});
_c2 = Converter;
var _c, _c1, _c2;
__turbopack_context__.k.register(_c, "StandardCard");
__turbopack_context__.k.register(_c1, "StandardText");
__turbopack_context__.k.register(_c2, "Converter");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/atoms/TokenAddressWithStandard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TokenAddressWithStandard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Tooltip.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/utils/getExplorerLink.ts [app-client] (ecmascript)");
;
;
;
;
;
function TokenAddressWithStandard({ tokenAddress, standard, chainId }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex text-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Tooltip$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                renderTrigger: (ref, refProps)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        onClick: (e)=>e.stopPropagation(),
                        ref: ref.setReference,
                        ...refProps,
                        className: "whitespace-nowrap border rounded-l-2 border-secondary-border bg-quaternary-bg px-2 flex items-center text-secondary-text cursor-pointer",
                        children: standard
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/TokenAddressWithStandard.tsx",
                        lineNumber: 22,
                        columnNumber: 11
                    }, void 0),
                iconSize: 16,
                text: standard === __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20 ? "Text" : "Text"
            }, void 0, false, {
                fileName: "[project]/app/components/atoms/TokenAddressWithStandard.tsx",
                lineNumber: 20,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$utils$2f$getExplorerLink$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ExplorerLinkType"].ADDRESS, tokenAddress, chainId),
                target: "_blank",
                className: "bg-quaternary-bg pl-2 pr-1 flex gap-1 py-px text-secondary-text hocus:text-primary-text hocus:bg-green-bg duration-200 border border-secondary-border rounded-r-2 items-center border-l-0",
                children: [
                    tokenAddress && `${tokenAddress.slice(0, 6)}...${tokenAddress.slice(-6)}`,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        size: 16,
                        iconName: "forward"
                    }, void 0, false, {
                        fileName: "[project]/app/components/atoms/TokenAddressWithStandard.tsx",
                        lineNumber: 42,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/components/atoms/TokenAddressWithStandard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/atoms/TokenAddressWithStandard.tsx",
        lineNumber: 19,
        columnNumber: 5
    }, this);
}
_c = TokenAddressWithStandard;
var _c;
__turbopack_context__.k.register(_c, "TokenAddressWithStandard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/organisms/SelectedTokensInfo.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SelectedTokenInfoItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TokenAddressWithStandard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/TokenAddressWithStandard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/config/standard.config.ts [app-client] (ecmascript)");
"use client";
;
;
;
;
// interface Props {
//   tokenA: Currency | undefined;
//   tokenB: Currency | undefined;
// }
// export default function SelectedTokensInfo({ tokenA, tokenB }: Props) {
//   if (!tokenA && !tokenB) {
//     return null;
//   }
//
//   if (tokenA && tokenB && tokenA.equals(tokenB)) {
//     return (
//       <div className="w-full bg-primary-bg p-4 sm:p-6 grid gap-3 rounded-5">
//         <SelectedTokenInfoItem token={tokenA} />
//       </div>
//     );
//   }
//
//   return (
//     <div className="w-full bg-primary-bg p-4 sm:p-6 grid gap-3 rounded-5">
//       {tokenA && <SelectedTokenInfoItem token={tokenA} />}
//       {tokenB && <SelectedTokenInfoItem token={tokenB} />}
//     </div>
//   );
// }
function AddressPair({ token }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex gap-2 flex-col md:flex-row",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TokenAddressWithStandard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                tokenAddress: token.address0,
                standard: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC20,
                chainId: token?.chainId
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$TokenAddressWithStandard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                tokenAddress: token.address1,
                standard: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$config$2f$standard$2e$config$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Standard"].ERC223,
                chainId: token.chainId
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                lineNumber: 41,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
        lineNumber: 35,
        columnNumber: 5
    }, this);
}
_c = AddressPair;
function SelectedTokenInfoItem({ token }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "bg-tertiary-bg pt-2.5 pb-3.5 px-5 @container relative z-20 rounded-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex justify-between gap-x-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between flex-wrap sm:flex-nowrap flex-grow gap-2",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                src: token.logoURI || "/images/tokens/placeholder.svg",
                                alt: "Ethereum",
                                width: 32,
                                height: 32,
                                className: "flex-shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                lineNumber: 55,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex gap-2 items-center",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "table table-fixed w-full",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "table-cell overflow-hidden overflow-ellipsis whitespace-nowrap",
                                                children: token.name
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                                lineNumber: 65,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                            lineNumber: 64,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                        lineNumber: 63,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "text-secondary-text text-12",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "table table-fixed w-full",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "table-cell overflow-hidden overflow-ellipsis whitespace-nowrap",
                                                children: token.symbol
                                            }, void 0, false, {
                                                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                                lineNumber: 72,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                            lineNumber: 71,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                        lineNumber: 70,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                                lineNumber: 62,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                    lineNumber: 53,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "w-full mt-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AddressPair, {
                    token: token
                }, void 0, false, {
                    fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                    lineNumber: 82,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
                lineNumber: 81,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/components/organisms/SelectedTokensInfo.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
_c1 = SelectedTokenInfoItem;
var _c, _c1;
__turbopack_context__.k.register(_c, "AddressPair");
__turbopack_context__.k.register(_c1, "SelectedTokenInfoItem");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/components/layout/Footer.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Footer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/clsx/dist/clsx.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Container.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/IconButton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/atoms/Svg.tsx [app-client] (ecmascript)");
"use client";
;
;
;
;
;
;
const socialLinks = [
    {
        title: "DEX223 Exchange",
        href: "https://app.dex223.com/",
        icon: "website"
    },
    {
        title: "Github",
        href: "https://github.com/Dexaran/dexaran.github.io",
        icon: "github"
    }
];
function FooterLink({ href, title, icon }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
            target: "_blank",
            href: href,
            className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$clsx$2f$dist$2f$clsx$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])("lg:w-auto text-12 lg:text-16 flex gap-2 bg-primary-bg rounded-5 lg:py-2 lg:pr-4 lg:pl-5 p-2 hover:bg-green-bg hover:text-primary-text text-secondary-text duration-200 w-full whitespace-nowrap justify-center items-center"),
            children: [
                title,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Svg$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    className: "!w-4 !h-4 lg:!w-6 lg:!h-6",
                    iconName: icon
                }, void 0, false, {
                    fileName: "[project]/app/components/layout/Footer.tsx",
                    lineNumber: 41,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/components/layout/Footer.tsx",
            lineNumber: 33,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_c = FooterLink;
function Footer() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
            className: "mt-[80px] before:h-[1px] before:bg-gradient-to-r before:from-secondary-border/20 before:via-50% before:via-secondary-border before:to-secondary-border/20 before:w-full before:absolute relative before:top-0 before:left-0 pb-[64px] md:pb-0",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$Container$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                className: "max-w-[1920px]",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex justify-between pt-4 pb-3 px-5 items-center flex-col-reverse sm:flex-row gap-3",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "rounded-20 p-1 flex items-center gap-2 bg-primary-bg",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    src: "/images/donut.svg",
                                    alt: "",
                                    width: 32,
                                    height: 32
                                }, void 0, false, {
                                    fileName: "[project]/app/components/layout/Footer.tsx",
                                    lineNumber: 54,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-tertiary-text",
                                    children: [
                                        "Donations appreciated: ",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-primary-text",
                                            children: "0x2ca1377dfa...e7d"
                                        }, void 0, false, {
                                            fileName: "[project]/app/components/layout/Footer.tsx",
                                            lineNumber: 56,
                                            columnNumber: 40
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/components/layout/Footer.tsx",
                                    lineNumber: 55,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    buttonSize: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButtonSize"].SMALL,
                                    variant: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$atoms$2f$IconButton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["IconButtonVariant"].COPY,
                                    text: "0x2ca1377dfa03577ce5bbb815c98eda1ac7632e7d"
                                }, void 0, false, {
                                    fileName: "[project]/app/components/layout/Footer.tsx",
                                    lineNumber: 58,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/components/layout/Footer.tsx",
                            lineNumber: 53,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            className: "text-tertiary-text underline hover:text-green duration-200",
                            href: "https://www.gnu.org/licenses/gpl-3.0.en.html",
                            children: "GPLv3"
                        }, void 0, false, {
                            fileName: "[project]/app/components/layout/Footer.tsx",
                            lineNumber: 64,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "grid grid-cols-2 sm:flex sm:items-center gap-2 sm:gap-3 w-full sm:w-auto",
                            children: socialLinks.map((socialLink)=>{
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(FooterLink, {
                                    ...socialLink
                                }, socialLink.title, false, {
                                    fileName: "[project]/app/components/layout/Footer.tsx",
                                    lineNumber: 72,
                                    columnNumber: 24
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/app/components/layout/Footer.tsx",
                            lineNumber: 70,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/components/layout/Footer.tsx",
                    lineNumber: 52,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/components/layout/Footer.tsx",
                lineNumber: 51,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/components/layout/Footer.tsx",
            lineNumber: 50,
            columnNumber: 7
        }, this)
    }, void 0, false);
}
_c1 = Footer;
var _c, _c1;
__turbopack_context__.k.register(_c, "FooterLink");
__turbopack_context__.k.register(_c1, "Footer");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/layout/Header.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$ConfirmConvertDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/organisms/ConfirmConvertDialog.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$Converter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/organisms/Converter.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$SelectedTokensInfo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/organisms/SelectedTokensInfo.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/stores/useConvertTokenStore.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/components/layout/Footer.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
function Home() {
    _s();
    const token = (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"])({
        "Home.useConvertTokensStore[token]": (state)=>state.token
    }["Home.useConvertTokensStore[token]"]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex flex-col px-10",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$Header$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 15,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$Converter$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$ConfirmConvertDialog$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 18,
                columnNumber: 7
            }, this),
            token && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$organisms$2f$SelectedTokensInfo$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                token: token
            }, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 20,
                columnNumber: 17
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$components$2f$layout$2f$Footer$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/app/page.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/page.tsx",
        lineNumber: 14,
        columnNumber: 5
    }, this);
}
_s(Home, "vKGZ55n/f6HLsQ9WL4Bky8mf+Y4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$stores$2f$useConvertTokenStore$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useConvertTokensStore"]
    ];
});
_c = Home;
var _c;
__turbopack_context__.k.register(_c, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=app_513a4e8b._.js.map