(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/config/tokens/1_predicted.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/config_tokens_1_predicted_json_10727827._.js",
  "static/chunks/config_tokens_1_predicted_json_ee0f8dee._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/config/tokens/1_predicted.json (json)");
    });
});
}),
]);