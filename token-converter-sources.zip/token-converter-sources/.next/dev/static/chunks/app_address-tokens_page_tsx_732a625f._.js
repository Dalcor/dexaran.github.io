(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_9c3cd8b1._.js",
  "static/chunks/_ba89f3e9._.js",
  "static/chunks/node_modules_viem__esm_df9ae197._.js",
  "static/chunks/node_modules_next_dist_compiled_1d6a8aa0._.js",
  "static/chunks/node_modules_c51a31e3._.js",
  "static/chunks/node_modules_simplebar-react_dist_simplebar_min_cfc4cb12.css"
],
    source: "dynamic"
});
