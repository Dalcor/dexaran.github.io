(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_e4afb629._.js",
  "static/chunks/app_743b90b7._.js",
  "static/chunks/node_modules_next_dist_aeb83da0._.js",
  "static/chunks/node_modules_viem__esm_3c8caff6._.js",
  "static/chunks/node_modules_4cdab715._.js",
  "static/chunks/node_modules_ox__esm_0a7b13c1._.js",
  "static/chunks/node_modules_lodash-es_94cab9d5._.js",
  "static/chunks/node_modules_119aab23._.js",
  "static/chunks/node_modules_simplebar-react_dist_simplebar_min_cfc4cb12.css"
],
    source: "dynamic"
});
