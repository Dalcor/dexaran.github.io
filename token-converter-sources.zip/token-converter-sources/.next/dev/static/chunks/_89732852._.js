(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/viem/_esm/utils/ccip.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_viem__esm_ef61fbee._.js",
  "static/chunks/node_modules_viem__esm_utils_ccip_f00df8e7.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/viem/_esm/utils/ccip.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript)");
    });
});
}),
"[project]/app/config/tokens/1_predicted.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/app_config_tokens_1_predicted_json_75fc29a0._.js",
  "static/chunks/app_config_tokens_1_predicted_json_afa6dec3._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/app/config/tokens/1_predicted.json (json)");
    });
});
}),
]);