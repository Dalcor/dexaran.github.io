(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/node_modules/viem/_esm/utils/ccip.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_viem__esm_ef61fbee._.js",
  "static/chunks/node_modules_viem__esm_utils_ccip_cea51b85.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/node_modules/viem/_esm/utils/ccip.js [app-client] (ecmascript)");
    });
});
}),
"[project]/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.resolve().then(() => {
        return parentImport("[project]/node_modules/@noble/curves/esm/secp256k1.js [app-client] (ecmascript)");
    });
});
}),
"[project]/config/tokens/1_predicted.json (json, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/config_tokens_1_predicted_json_10727827._.js",
  "static/chunks/config_tokens_1_predicted_json_919a8629._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/config/tokens/1_predicted.json (json)");
    });
});
}),
]);