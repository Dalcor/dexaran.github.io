import { createDialogStateStore } from "@/stores/factories/createDialogStateStore";

export const useConfirmConvertDialogStore = createDialogStateStore();
