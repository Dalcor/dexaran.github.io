export const IIFE = (fn: (...args: unknown[]) => unknown) => {
  fn();
};
